# Project Talon — Complete Deployment Guide

**Version:** 2.0  
**Date:** March 2026  
**Components:** Backend (Python/FastAPI) · Web Chat UI (React) · Dashboard UI (React)

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Project Structure](#2-project-structure)
3. [Backend Deployment](#3-backend-deployment)
4. [Web Chat UI Deployment](#4-web-chat-ui-deployment)
5. [Dashboard UI Deployment](#5-dashboard-ui-deployment)
6. [Microsoft Teams Bot Setup](#6-microsoft-teams-bot-setup)
7. [LLM Provider Configuration](#7-llm-provider-configuration)
8. [Local LLM (LM Studio / Ollama)](#8-local-llm-lm-studio--ollama)
9. [Production Deployment](#9-production-deployment)
10. [Troubleshooting](#10-troubleshooting)

---

## 1. Prerequisites

### Required
| Tool | Version | Install |
|------|---------|---------|
| Python | 3.11+ | https://python.org |
| Node.js | 18+ | https://nodejs.org |
| pnpm | 8+ | `npm install -g pnpm` |

### Optional (for Teams integration)
- Azure account (free tier works)
- ngrok (for local Teams development) — https://ngrok.com

### LLM Provider (pick at least one)
| Provider | What you need |
|----------|--------------|
| Anthropic Claude | API key from https://console.anthropic.com |
| OpenAI | API key from https://platform.openai.com |
| Google Gemini | API key from https://aistudio.google.com |
| LM Studio (local) | Download from https://lmstudio.ai — **no API key needed** |
| Ollama (local) | Download from https://ollama.ai — **no API key needed** |

---

## 2. Project Structure

After extracting `talon-complete.tar.gz`:

```
talon-complete/
├── talon-backend/          ← Python backend (FastAPI + agents + tools)
├── talon-webchat/          ← Web Chat React app (real-time chat per agent)
└── talon-app/              ← Dashboard React app (monitoring & control plane)
```

---

## 3. Backend Deployment

### Step 1 — Extract and install

```bash
tar -xzf talon-complete.tar.gz
cd talon-backend
```

```bash
# Create a virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate        # Linux/macOS
# venv\Scripts\activate         # Windows

# Install dependencies
pip install -r requirements.txt
```

### Step 2 — Configure environment

```bash
cp .env.example .env
```

Open `.env` and fill in at minimum:

```env
# ── Required: pick at least one LLM provider ──────────────────────────────────
ANTHROPIC_API_KEY=sk-ant-...          # Claude (recommended)
# OPENAI_API_KEY=sk-...              # GPT-4o (alternative)
# GEMINI_API_KEY=...                 # Gemini (alternative)

# ── Local LLM (LM Studio / Ollama) — no API key needed ────────────────────────
# LOCAL_LLM_BASE_URL=http://localhost:1234/v1    # LM Studio default
# LOCAL_LLM_BASE_URL=http://localhost:11434/v1   # Ollama default
# LOCAL_LLM_API_KEY=lm-studio                    # any string
# LOCAL_LLM_MODEL=llama-3.2-3b-instruct

# ── Optional: Teams bot (only needed for Teams integration) ────────────────────
# TEAMS_APP_ID=<your-azure-bot-app-id>
# TEAMS_APP_PASSWORD=<your-azure-bot-secret>

# ── Server ─────────────────────────────────────────────────────────────────────
HOST=0.0.0.0
PORT=8000
LOG_LEVEL=INFO

# ── Database (SQLite is default, no setup needed) ──────────────────────────────
DATABASE_URL=sqlite:///talon.db
```

### Step 3 — Configure agents

Edit `config/agents.yaml` to set the LLM provider per agent:

```yaml
agents:
  alex-sre:
    name: "Alex"
    role: "SRE Digital Employee"
    llm:
      provider: "anthropic"                    # anthropic | openai | local | gemini
      model: "claude-3-5-haiku-20241022"
    # ... rest of config

  morgan-data:
    name: "Morgan"
    role: "Data Analyst"
    llm:
      provider: "local"                        # Uses LM Studio or Ollama
      model: "llama-3.2-3b-instruct"
      base_url: "http://localhost:1234/v1"
      api_key: "lm-studio"
```

### Step 4 — Start the backend

```bash
python main.py
```

Expected output:
```
INFO:     Project Talon backend starting...
INFO:     Loaded 5 agents: alex-sre, dana-helpdesk, morgan-data, casey-security, jordan-finance
INFO:     Database initialized: talon.db
INFO:     Uvicorn running on http://0.0.0.0:8000
```

### Step 5 — Verify it works

```bash
# Health check
curl http://localhost:8000/api/health

# List agents
curl http://localhost:8000/api/agents

# Send a test message to Alex (no Teams needed!)
curl -X POST http://localhost:8000/api/employees/alex-sre/message \
  -H "Content-Type: application/json" \
  -d '{"message": "What time is it in Tokyo?", "user": "test-user"}'
```

You should get a real AI response within a few seconds.

---

## 4. Web Chat UI Deployment

### Option A — Run locally (dev mode)

```bash
cd talon-webchat

# Install dependencies
pnpm install

# Start dev server
pnpm dev
# → Opens at http://localhost:5173
```

When the chat opens, enter `http://localhost:8000` as the backend URL.

### Option B — Build and serve as static files

```bash
cd talon-webchat
pnpm install
pnpm build           # Creates dist/ folder

# Serve with Python (no install needed)
cd dist
python3 -m http.server 3001
# → Opens at http://localhost:3001

# OR with Node serve
npx serve -s dist -l 3001
```

### Option C — Use the already-deployed version

The Web Chat is already live at:  
**https://4wtktnaqtk.space.minimax.io**

Just open it, enter your backend URL (or ngrok URL if running locally), and start chatting.

### Connecting the Web Chat to the backend

When you open the Web Chat, it shows a setup screen:

1. Enter your backend URL (e.g. `http://localhost:8000` for local)
2. Click **Connect** — it tests the connection automatically
3. Select an agent and start chatting

> **Note:** If your Web Chat is on a different domain than the backend,  
> make sure `CORS` is allowed. The backend allows all origins by default.

---

## 5. Dashboard UI Deployment

### Option A — Run locally (dev mode)

```bash
cd talon-app
pnpm install
pnpm dev
# → http://localhost:5174
```

### Option B — Serve the pre-built dist

The `dist/` folder is included in the archive:

```bash
cd talon-app/dist
python3 -m http.server 3002
# → http://localhost:3002
```

### Option C — Use the already-deployed version

Dashboard is live at:  
**https://ab9bktklix.space.minimax.io**

> Note: The dashboard currently shows mock/simulated data. To connect it to real backend data, the frontend API calls need to point to your backend URL. This can be added in a future update.

---

## 6. Microsoft Teams Bot Setup

### Step 1 — Register an Azure Bot

1. Go to [portal.azure.com](https://portal.azure.com)
2. Search for **Azure Bot** → click **Create**
3. Fill in:
   - **Bot handle:** `talon-alex` (or any name)
   - **Subscription:** your Azure subscription
   - **Resource group:** create new or use existing
   - **Pricing tier:** F0 (free)
   - **Microsoft App ID:** select *Create new Microsoft App ID*
4. Click **Review + Create** → **Create**
5. Once created, go to the bot resource → **Configuration**
6. Note down the **Microsoft App ID**
7. Go to **Microsoft App ID** link → **Certificates & secrets** → **New client secret**
8. Copy the secret value immediately (shown only once)

### Step 2 — Add credentials to .env

```env
TEAMS_APP_ID=<Microsoft App ID from step 6>
TEAMS_APP_PASSWORD=<Secret value from step 7>
```

Restart the backend: `python main.py`

### Step 3 — Expose backend publicly (for local dev: use ngrok)

```bash
# Install ngrok: https://ngrok.com/download
ngrok http 8000
# → Forwarding: https://xxxx.ngrok-free.app → localhost:8000
```

Copy the `https://xxxx.ngrok-free.app` URL.

### Step 4 — Set the messaging endpoint

1. Back in Azure Portal → your bot → **Configuration**
2. Set **Messaging endpoint** to:  
   `https://xxxx.ngrok-free.app/api/messages`
3. Click **Apply**

### Step 5 — Enable Teams channel

1. In your bot → **Channels** → click **Microsoft Teams**
2. Accept the terms → **Save**

### Step 6 — Create Teams App manifest

Create a file `teams-manifest/manifest.json`:

```json
{
  "$schema": "https://developer.microsoft.com/en-us/json-schemas/teams/v1.16/MicrosoftTeams.schema.json",
  "manifestVersion": "1.16",
  "version": "1.0.0",
  "id": "<YOUR-TEAMS-APP-ID>",
  "packageName": "com.yourcompany.talon",
  "developer": {
    "name": "Your Company",
    "websiteUrl": "https://yourcompany.com",
    "privacyUrl": "https://yourcompany.com/privacy",
    "termsOfUseUrl": "https://yourcompany.com/terms"
  },
  "name": {
    "short": "Alex (SRE)",
    "full": "Alex — Talon SRE Digital Employee"
  },
  "description": {
    "short": "AI SRE Digital Employee",
    "full": "Alex is an AI-powered SRE digital employee that helps with incidents, monitoring, and infrastructure."
  },
  "icons": {
    "outline": "outline.png",
    "color": "color.png"
  },
  "accentColor": "#3B82F6",
  "bots": [
    {
      "botId": "<YOUR-MICROSOFT-APP-ID>",
      "scopes": ["team", "personal", "groupchat"],
      "isNotificationOnly": false,
      "supportsCalling": false,
      "supportsVideo": false,
      "supportsFiles": false
    }
  ],
  "permissions": ["identity", "messageTeamMembers"],
  "validDomains": []
}
```

Replace `<YOUR-MICROSOFT-APP-ID>` with your bot's App ID.

### Step 7 — Package and install

```bash
cd teams-manifest
# Add two icon images: color.png (192x192) and outline.png (32x32)
zip -r talon-alex.zip manifest.json color.png outline.png
```

1. Open Microsoft Teams → **Apps** → **Upload a custom app**
2. Upload `talon-alex.zip`
3. Click **Add** → Add to a team or chat
4. Go to that Teams channel and type `@Alex hello!`

---

## 7. LLM Provider Configuration

### Summary table

| Provider | Config key | Env var needed |
|----------|-----------|----------------|
| Anthropic | `provider: "anthropic"` | `ANTHROPIC_API_KEY` |
| OpenAI | `provider: "openai"` | `OPENAI_API_KEY` |
| Local (LM Studio) | `provider: "local"` + `base_url` | None |
| Local (Ollama) | `provider: "local"` + `base_url` | None |
| Google Gemini | `provider: "gemini"` | `GEMINI_API_KEY` |

### Per-agent configuration in `agents.yaml`

```yaml
# Example: Mix providers across agents
agents:
  alex-sre:
    llm:
      provider: "anthropic"
      model: "claude-3-5-haiku-20241022"   # fast + cheap

  dana-helpdesk:
    llm:
      provider: "openai"
      model: "gpt-4o-mini"

  morgan-data:
    llm:
      provider: "local"
      model: "llama-3.2-8b-instruct"
      base_url: "http://localhost:1234/v1"
      api_key: "lm-studio"

  casey-security:
    llm:
      provider: "anthropic"
      model: "claude-3-5-sonnet-20241022"  # smarter model for security analysis

  jordan-finance:
    llm:
      provider: "gemini"
      model: "gemini-1.5-flash"
```

---

## 8. Local LLM (LM Studio / Ollama)

### LM Studio Setup

1. Download from https://lmstudio.ai
2. Open LM Studio → **Discover** tab
3. Search for a model: recommended `llama-3.2-3b-instruct` or `qwen2.5-7b-instruct`
4. Download and load the model
5. Go to **Local Server** tab → **Start Server**
6. Server runs at `http://localhost:1234/v1` by default

Configure in `agents.yaml`:
```yaml
llm:
  provider: "local"
  model: "llama-3.2-3b-instruct"   # must match loaded model name in LM Studio
  base_url: "http://localhost:1234/v1"
  api_key: "lm-studio"
```

### Ollama Setup

```bash
# Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Pull a model
ollama pull llama3.2
ollama pull mistral
ollama pull qwen2.5

# Ollama serves at http://localhost:11434 automatically
```

Configure in `agents.yaml`:
```yaml
llm:
  provider: "local"
  model: "llama3.2"      # must match ollama model name
  base_url: "http://localhost:11434/v1"
  api_key: "ollama"
```

### Recommended models for tool use

| Model | Size | Tool calling | Notes |
|-------|------|-------------|-------|
| `llama-3.2-3b-instruct` | 3B | ✅ Native | Fast, good for simple tasks |
| `llama-3.2-8b-instruct` | 8B | ✅ Native | Better reasoning |
| `qwen2.5-7b-instruct` | 7B | ✅ Native | Excellent tool use |
| `mistral-7b-instruct` | 7B | ⚠️ Fallback | Uses ReAct text fallback |
| `phi-3.5-mini` | 3.8B | ⚠️ Fallback | Lightweight, mixed results |

> Models marked **⚠️ Fallback** will use the automatic ReAct text prompting fallback when native tool calling fails.

---

## 9. Production Deployment

### Backend — systemd service (Linux)

Create `/etc/systemd/system/talon.service`:

```ini
[Unit]
Description=Project Talon Backend
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/talon/talon-backend
EnvironmentFile=/opt/talon/talon-backend/.env
ExecStart=/opt/talon/venv/bin/python main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable talon
sudo systemctl start talon
sudo systemctl status talon
```

### Backend — Docker

Create `talon-backend/Dockerfile`:

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000
CMD ["python", "main.py"]
```

```bash
docker build -t talon-backend .
docker run -d \
  --name talon \
  -p 8000:8000 \
  -e ANTHROPIC_API_KEY=sk-ant-... \
  -v $(pwd)/talon.db:/app/talon.db \
  talon-backend
```

### Web Chat — nginx

```nginx
server {
    listen 80;
    server_name chat.yourcompany.com;
    root /var/www/talon-webchat/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Proxy backend API
    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # Proxy WebSocket
    location /ws {
        proxy_pass http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

```bash
cd talon-webchat && pnpm build
sudo cp -r dist/* /var/www/talon-webchat/dist/
sudo nginx -s reload
```

---

## 10. Troubleshooting

### Backend won't start
```
Error: No module named 'anthropic'
→ Run: pip install -r requirements.txt

Error: ANTHROPIC_API_KEY not set
→ Add it to your .env file
```

### Agent returns an error about API key
```
⚠️ Configuration error: ANTHROPIC_API_KEY not configured
→ Check your .env file has the right key
→ Make sure you restarted the backend after editing .env
```

### Local LLM not connecting
```
Error: Connection refused localhost:1234
→ LM Studio: make sure "Start Server" is clicked in the Local Server tab
→ Ollama: run `ollama serve` or check `ollama ps`
→ Verify the base_url in agents.yaml matches the actual port
```

### Teams bot not receiving messages
```
→ Check ngrok is still running (free ngrok URLs expire)
→ Verify the messaging endpoint in Azure matches your ngrok URL exactly
→ Check backend logs: python main.py shows incoming requests
→ The endpoint must be HTTPS (ngrok provides this automatically)
```

### WebSocket connection fails in Web Chat
```
→ Make sure the backend is running
→ Check the URL you entered doesn't have a trailing slash
→ If backend is HTTPS, use wss:// (the app converts automatically)
→ Check browser console for CORS errors
```

### Teams bot doesn't reply
```
→ Check TEAMS_APP_ID and TEAMS_APP_PASSWORD in .env match Azure exactly
→ Look at backend logs for incoming /api/messages requests
→ Verify HMAC signature verification is passing (check logs for "HMAC" errors)
```

---

## Quick Reference Card

```bash
# Start backend
cd talon-backend && python main.py

# Test agent (no Teams needed)
curl -X POST http://localhost:8000/api/employees/alex-sre/message \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello!", "user": "me"}'

# Start web chat dev server
cd talon-webchat && pnpm dev

# Start dashboard dev server
cd talon-app && pnpm dev

# Expose backend for Teams (local dev)
ngrok http 8000

# Check backend health
curl http://localhost:8000/api/health

# View agents
curl http://localhost:8000/api/agents

# View audit trail
curl http://localhost:8000/api/audit/events
```

---

*Project Talon — Enterprise Agentic Framework*  
*Design: claude_agentic_enterprise_foundations_design_plan.md*
