import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import DigitalEmployees from './pages/DigitalEmployees';
import ReActLoop from './pages/ReActLoop';
import MemoryExplorer from './pages/MemoryExplorer';
import ToolFramework from './pages/ToolFramework';
import AuditTrail from './pages/AuditTrail';
import Observability from './pages/Observability';
import ControlPlane from './pages/ControlPlane';
import Orchestration from './pages/Orchestration';
import { AppProvider } from './context/AppContext';

export default function App() {
  return (
    <AppProvider>
      <div className="min-h-screen bg-slate-950 text-slate-100 flex">
        <Sidebar />
        <main className="flex-1 ml-16 lg:ml-56 min-h-screen">
          <div className="max-w-[1600px] mx-auto p-4 lg:p-6">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/employees" element={<DigitalEmployees />} />
              <Route path="/react-loop" element={<ReActLoop />} />
              <Route path="/memory" element={<MemoryExplorer />} />
              <Route path="/tools" element={<ToolFramework />} />
              <Route path="/audit" element={<AuditTrail />} />
              <Route path="/observability" element={<Observability />} />
              <Route path="/control" element={<ControlPlane />} />
              <Route path="/orchestration" element={<Orchestration />} />
            </Routes>
          </div>
        </main>
      </div>
    </AppProvider>
  );
}
