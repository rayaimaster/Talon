import { DigitalEmployee, AuditEvent, HitlRequest, DelegationLink, Tool, MemoryEntry, ActivityEvent } from '../types';

export const EMPLOYEES: DigitalEmployee[] = [
  {
    id: 'alex',
    name: 'Alex',
    role: 'Site Reliability Engineer',
    emoji: '🛡️',
    color: '#3b82f6',
    colorClass: 'text-blue-400',
    bgClass: 'bg-blue-500/20',
    borderClass: 'border-blue-500/40',
    status: 'active',
    currentTask: 'Investigating high CPU alert on prod-k8s-node-07',
    capabilities: ['Kubernetes ops', 'Incident response', 'Log analysis', 'Alert triage', 'Runbook execution'],
    tools: ['kubectl', 'Splunk', 'PagerDuty', 'Prometheus', 'Grafana', 'AWS CLI', 'Terraform'],
    channels: ['#sre-alerts', '#incidents', '#devops', 'Email'],
    conversationsToday: 34,
    completionRate: 94,
    escalationRate: 6,
    avgResponseTime: 1.2,
    tokensUsed: 124500,
    costToday: 3.82,
    episodicMemories: 847,
    entityRecords: 234,
    kbHits: 1203,
    reactState: 'act',
  },
  {
    id: 'dana',
    name: 'Dana',
    role: 'IT HelpDesk Specialist',
    emoji: '💚',
    color: '#22c55e',
    colorClass: 'text-green-400',
    bgClass: 'bg-green-500/20',
    borderClass: 'border-green-500/40',
    status: 'active',
    currentTask: 'Resetting MFA for user john.smith@corp.com',
    capabilities: ['User provisioning', 'Device management', 'Password resets', 'Software installs', 'Ticket triage'],
    tools: ['ServiceNow', 'Okta', 'Jamf', 'Azure AD', 'Jira', 'Slack API'],
    channels: ['#it-helpdesk', '#general', 'Teams', 'Email'],
    conversationsToday: 67,
    completionRate: 89,
    escalationRate: 11,
    avgResponseTime: 0.8,
    tokensUsed: 98200,
    costToday: 2.94,
    episodicMemories: 1203,
    entityRecords: 567,
    kbHits: 2341,
    reactState: 'perceive',
  },
  {
    id: 'morgan',
    name: 'Morgan',
    role: 'Data Analyst',
    emoji: '🔮',
    color: '#a855f7',
    colorClass: 'text-purple-400',
    bgClass: 'bg-purple-500/20',
    borderClass: 'border-purple-500/40',
    status: 'active',
    currentTask: 'Generating Q1 revenue forecast model',
    capabilities: ['SQL queries', 'Python analysis', 'Dashboard creation', 'Report generation', 'Data pipeline monitoring'],
    tools: ['Snowflake', 'dbt', 'Tableau', 'Python', 'Jupyter', 'Airflow', 'BigQuery'],
    channels: ['#data-team', '#analytics', '#exec-reports', 'Email'],
    conversationsToday: 18,
    completionRate: 97,
    escalationRate: 3,
    avgResponseTime: 2.4,
    tokensUsed: 187300,
    costToday: 5.61,
    episodicMemories: 432,
    entityRecords: 891,
    kbHits: 1876,
    reactState: 'plan',
  },
  {
    id: 'casey',
    name: 'Casey',
    role: 'Security Analyst',
    emoji: '🔒',
    color: '#f97316',
    colorClass: 'text-orange-400',
    bgClass: 'bg-orange-500/20',
    borderClass: 'border-orange-500/40',
    status: 'idle',
    currentTask: 'Monitoring threat feeds — no active incidents',
    capabilities: ['Threat detection', 'Vulnerability scanning', 'SIEM analysis', 'Incident response', 'Compliance checks'],
    tools: ['Splunk SIEM', 'CrowdStrike', 'Tenable.io', 'Okta', 'PAN-OS', 'VirusTotal'],
    channels: ['#security-ops', '#incidents', '#compliance', 'Email'],
    conversationsToday: 12,
    completionRate: 100,
    escalationRate: 0,
    avgResponseTime: 1.8,
    tokensUsed: 67800,
    costToday: 2.03,
    episodicMemories: 623,
    entityRecords: 412,
    kbHits: 987,
    reactState: 'observe',
  },
  {
    id: 'jordan',
    name: 'Jordan',
    role: 'Project Coordinator',
    emoji: '📋',
    color: '#eab308',
    colorClass: 'text-yellow-400',
    bgClass: 'bg-yellow-500/20',
    borderClass: 'border-yellow-500/40',
    status: 'active',
    currentTask: 'Scheduling sprint planning meeting for Team Phoenix',
    capabilities: ['Meeting scheduling', 'Status tracking', 'Jira management', 'Stakeholder updates', 'Risk tracking'],
    tools: ['Jira', 'Confluence', 'MS Teams', 'Google Calendar', 'Slack', 'Notion'],
    channels: ['#project-mgmt', '#team-phoenix', '#leadership', 'Teams', 'Email'],
    conversationsToday: 29,
    completionRate: 92,
    escalationRate: 8,
    avgResponseTime: 1.1,
    tokensUsed: 54300,
    costToday: 1.63,
    episodicMemories: 734,
    entityRecords: 345,
    kbHits: 1543,
    reactState: 'decide',
  },
];

export const TOOL_CATEGORIES = [
  {
    id: 'compute',
    name: 'Compute Agency',
    icon: 'Terminal',
    color: 'blue',
    tools: [
      { name: 'Bash Shell', status: 'in-use', usageCount: 234 },
      { name: 'Python Runtime', status: 'available', usageCount: 189 },
      { name: 'kubectl', status: 'in-use', usageCount: 156 },
      { name: 'Docker CLI', status: 'available', usageCount: 98 },
      { name: 'Terraform', status: 'available', usageCount: 67 },
      { name: 'AWS CLI', status: 'available', usageCount: 145 },
    ],
  },
  {
    id: 'browser',
    name: 'Browser Agency',
    icon: 'Globe',
    color: 'green',
    tools: [
      { name: 'Playwright', status: 'available', usageCount: 78 },
      { name: 'Puppeteer', status: 'rate-limited', usageCount: 45 },
      { name: 'Web Scraper', status: 'available', usageCount: 123 },
      { name: 'Form Filler', status: 'available', usageCount: 34 },
    ],
  },
  {
    id: 'communication',
    name: 'Communication Agency',
    icon: 'MessageSquare',
    color: 'purple',
    tools: [
      { name: 'Email (SMTP)', status: 'available', usageCount: 456 },
      { name: 'MS Teams API', status: 'in-use', usageCount: 892 },
      { name: 'Slack API', status: 'in-use', usageCount: 734 },
      { name: 'Google Calendar', status: 'available', usageCount: 234 },
      { name: 'Outlook Calendar', status: 'available', usageCount: 189 },
    ],
  },
  {
    id: 'files',
    name: 'File & Document Agency',
    icon: 'FileText',
    color: 'orange',
    tools: [
      { name: 'SharePoint', status: 'available', usageCount: 345 },
      { name: 'Google Drive', status: 'available', usageCount: 267 },
      { name: 'Confluence', status: 'in-use', usageCount: 189 },
      { name: 'PDF Generator', status: 'available', usageCount: 78 },
      { name: 'OCR Engine', status: 'available', usageCount: 45 },
    ],
  },
  {
    id: 'saas',
    name: 'Enterprise SaaS Agency',
    icon: 'Boxes',
    color: 'yellow',
    tools: [
      { name: 'Jira', status: 'in-use', usageCount: 567 },
      { name: 'ServiceNow', status: 'in-use', usageCount: 423 },
      { name: 'Salesforce', status: 'available', usageCount: 234 },
      { name: 'PagerDuty', status: 'in-use', usageCount: 189 },
      { name: 'Okta', status: 'available', usageCount: 312 },
      { name: 'Workday', status: 'available', usageCount: 67 },
    ],
  },
  {
    id: 'data',
    name: 'Data Agency',
    icon: 'Database',
    color: 'red',
    tools: [
      { name: 'Snowflake', status: 'in-use', usageCount: 678 },
      { name: 'Splunk', status: 'in-use', usageCount: 534 },
      { name: 'BigQuery', status: 'available', usageCount: 289 },
      { name: 'Elasticsearch', status: 'available', usageCount: 234 },
      { name: 'Redis', status: 'available', usageCount: 178 },
      { name: 'PostgreSQL', status: 'available', usageCount: 445 },
    ],
  },
];

export const SANDBOX_PROFILES = [
  { name: 'minimal', network: false, filesystem: 'read-only', processes: 1, tools: 'None', useCase: 'Read-only Q&A' },
  { name: 'standard', network: true, filesystem: 'user-home', processes: 5, tools: 'Basic', useCase: 'General helpdesk' },
  { name: 'compute', network: true, filesystem: 'workspace', processes: 20, tools: 'Full compute', useCase: 'Data analysis, SRE' },
  { name: 'browser', network: true, filesystem: 'temp', processes: 10, tools: 'Browser + compute', useCase: 'Web automation' },
  { name: 'restricted', network: 'allowlist', filesystem: 'read-only', processes: 2, tools: 'Read-only APIs', useCase: 'Compliance/audit' },
];

const eventTypes = [
  'tool.invoked', 'shell.executed', 'hitl.requested', 'email.sent',
  'memory.stored', 'api.called', 'browser.action', 'file.written',
  'escalation.triggered', 'checkpoint.saved', 'delegation.started',
];

function randomHash(): string {
  return Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
}

function randomItem<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function generateAuditEvents(count: number): AuditEvent[] {
  const events: AuditEvent[] = [];
  const employees = EMPLOYEES;
  const now = new Date();

  for (let i = 0; i < count; i++) {
    const emp = randomItem(employees);
    const eventType = randomItem(eventTypes);
    const riskLevels: AuditEvent['riskLevel'][] = ['low', 'low', 'low', 'medium', 'medium', 'high', 'critical'];
    const outcomes: AuditEvent['outcome'][] = ['success', 'success', 'success', 'success', 'failure', 'pending'];

    events.push({
      id: `evt-${i}-${randomHash()}`,
      timestamp: new Date(now.getTime() - (count - i) * 45000 - Math.random() * 30000),
      employeeId: emp.id,
      employeeName: emp.name,
      eventType,
      action: getActionDescription(eventType, emp.name),
      riskLevel: randomItem(riskLevels),
      outcome: randomItem(outcomes),
      hash: randomHash(),
      detail: getEventDetail(eventType),
    });
  }
  return events;
}

function getActionDescription(eventType: string, name: string): string {
  const map: Record<string, string[]> = {
    'tool.invoked': [`${name} invoked kubectl get pods`, `${name} ran Splunk query`, `${name} called PagerDuty API`, `${name} executed Terraform plan`],
    'shell.executed': [`${name} ran bash script: health-check.sh`, `${name} executed: kubectl drain node-07`, `${name} ran: aws ec2 describe-instances`],
    'hitl.requested': [`${name} requested approval for prod deployment`, `${name} escalated security alert to SOC`, `${name} requested review for email blast`],
    'email.sent': [`${name} sent incident report to ops-team@corp.com`, `${name} sent status update to leadership`, `${name} sent alert digest`],
    'memory.stored': [`${name} stored incident runbook outcome`, `${name} saved user preference`, `${name} indexed new KB article`],
    'api.called': [`${name} called Jira API: createIssue`, `${name} called ServiceNow: resolveTicket`, `${name} called Okta: resetMFA`],
    'browser.action': [`${name} navigated to Grafana dashboard`, `${name} filled form on ServiceNow portal`, `${name} scraped status page`],
    'file.written': [`${name} wrote incident report.pdf`, `${name} updated runbook.md`, `${name} exported data to CSV`],
    'escalation.triggered': [`${name} escalated P1 incident to on-call SRE`, `${name} escalated to security team`, `${name} paged VP Engineering`],
    'checkpoint.saved': [`${name} saved ReAct checkpoint at iteration 47`, `${name} saved state before risky operation`, `${name} checkpointed long-running analysis`],
    'delegation.started': [`${name} delegated task to Morgan`, `${name} requested data pull from Morgan`, `${name} asked Casey to verify threat`],
  };
  return randomItem(map[eventType] || [`${name} performed ${eventType}`]);
}

function getEventDetail(eventType: string): string {
  const details: Record<string, string[]> = {
    'tool.invoked': ['sandbox=compute, timeout=30s', 'sandbox=restricted, read-only', 'api_key=masked, retries=3'],
    'shell.executed': ['exit_code=0, duration=2.3s', 'exit_code=0, output=14 lines', 'exit_code=1, stderr captured'],
    'hitl.requested': ['risk=high, awaiting_approval', 'policy=prd-deploy-approval', 'timeout=300s'],
    'email.sent': ['recipients=3, size=2.4KB', 'recipients=12, attachments=1', 'DKIM=pass, SPF=pass'],
    'memory.stored': ['tier=2, embedding=stored', 'tier=3, entity_updated', 'tier=4, kb_indexed'],
    'api.called': ['status=200, latency=134ms', 'status=201, created', 'status=429, rate-limited, retry in 60s'],
    'browser.action': ['screenshot=saved, duration=1.8s', 'element_found, clicked', 'page_loaded, extracted_text'],
    'file.written': ['bytes=45231, path=/workspace', 'bytes=1204, encrypted=true', 'bytes=892103, s3_uploaded'],
    'escalation.triggered': ['channel=#incidents, notified=3', 'pagerduty_alert_id=INC-4521', 'severity=P1'],
    'checkpoint.saved': ['size=2.3MB, compressed', 'iteration=47, tokens=124k', 'rollback_available=true'],
    'delegation.started': ['task_id=dlg-4521, deadline=2h', 'subtask_count=3, parallel=true', 'context_transferred=true'],
  };
  return randomItem(details[eventType] || ['No additional detail']);
}

export function generateActivityFeed(count: number): ActivityEvent[] {
  const events: ActivityEvent[] = [];
  const employees = EMPLOYEES;
  const now = new Date();

  const actions = [
    { type: 'tool' as const, msgs: ['Ran kubectl get pods on prod cluster', 'Queried Splunk for error logs', 'Called PagerDuty API', 'Executed Terraform plan', 'Ran Python analysis script'] },
    { type: 'message' as const, msgs: ['Replied to IT ticket #45821', 'Sent status update to #sre-alerts', 'Answered question in #data-team', 'Sent incident report via email'] },
    { type: 'proactive' as const, msgs: ['Fired heartbeat check — all systems healthy', 'Proactive: detected anomaly in metrics', 'Scheduled task: daily report generated', 'Alert: CPU spike on prod-node-07'] },
    { type: 'escalation' as const, msgs: ['Escalated P1 incident to on-call engineer', 'Requested HITL approval for prod change', 'Alerted security team to suspicious activity'] },
    { type: 'memory' as const, msgs: ['Stored incident outcome to episodic memory', 'Retrieved 3 relevant runbooks from KB', 'Updated entity record for user john.smith'] },
    { type: 'delegation' as const, msgs: ['Delegated data pull to Morgan', 'Received task from Alex — running analysis', 'Completed delegated sub-task'] },
  ];

  for (let i = 0; i < count; i++) {
    const emp = randomItem(employees);
    const action = randomItem(actions);
    const msg = randomItem(action.msgs);
    events.push({
      id: `act-${i}-${Math.random().toString(36).slice(2)}`,
      timestamp: new Date(now.getTime() - (count - i) * 8000 - Math.random() * 5000),
      employeeId: emp.id,
      employeeName: emp.name,
      action: msg,
      detail: '',
      type: action.type,
    });
  }
  return events;
}

export function generateHitlRequests(): HitlRequest[] {
  return [
    {
      id: 'hitl-001',
      employeeId: 'alex',
      employeeName: 'Alex',
      task: 'Drain and replace production Kubernetes node prod-k8s-node-07',
      reason: 'Node replacement requires draining workloads — potential brief service interruption',
      riskLevel: 'high',
      timestamp: new Date(Date.now() - 300000),
      status: 'pending',
    },
    {
      id: 'hitl-002',
      employeeId: 'dana',
      employeeName: 'Dana',
      task: 'Send MFA reset instructions to 47 users affected by Okta sync issue',
      reason: 'Bulk communication to >20 users requires approval per email policy',
      riskLevel: 'medium',
      timestamp: new Date(Date.now() - 600000),
      status: 'pending',
    },
    {
      id: 'hitl-003',
      employeeId: 'casey',
      employeeName: 'Casey',
      task: 'Block IP range 185.220.101.0/24 on perimeter firewall',
      reason: 'Blocking external IP range — verify not legitimate traffic',
      riskLevel: 'critical',
      timestamp: new Date(Date.now() - 900000),
      status: 'pending',
    },
    {
      id: 'hitl-004',
      employeeId: 'morgan',
      employeeName: 'Morgan',
      task: 'Export Q1 financial data to external partner BI tool',
      reason: 'Data export to external system requires compliance approval',
      riskLevel: 'high',
      timestamp: new Date(Date.now() - 1200000),
      status: 'pending',
    },
  ];
}

export function generateDelegationLinks(): DelegationLink[] {
  return [
    { from: 'alex', to: 'morgan', task: 'Analyze error rate trends from Splunk data', status: 'active' },
    { from: 'alex', to: 'casey', task: 'Verify if spike is security-related', status: 'active' },
    { from: 'dana', to: 'alex', task: 'Confirm infra side of SSO outage', status: 'completed' },
    { from: 'jordan', to: 'dana', task: 'Get ticket counts for sprint report', status: 'pending' },
    { from: 'jordan', to: 'morgan', task: 'Pull team velocity metrics for Q1', status: 'active' },
  ];
}

export const MEMORY_TIERS = [
  {
    tier: 0,
    name: 'Working Memory',
    desc: 'Current activation scratchpad — in-context reasoning',
    icon: 'Zap',
    capacity: '128K tokens',
    used: '34K tokens',
    entries: [
      { id: 'wm-1', content: 'Current task: Investigating CPU spike on prod-k8s-node-07. Plan: 1) Check pod resource limits 2) Review recent deployments 3) Check node metrics', timestamp: new Date(), tags: ['active', 'incident'] },
      { id: 'wm-2', content: 'Tool results: kubectl top node → node-07 CPU 94%. kubectl get events → OOMKilled 3x in last hour', timestamp: new Date(), tags: ['tool-result'] },
      { id: 'wm-3', content: 'Hypothesis: New deployment v2.4.1 of payment-service causing memory leak → CPU thrashing', timestamp: new Date(), tags: ['hypothesis'] },
    ],
  },
  {
    tier: 1,
    name: 'Conversation History',
    desc: 'Compressed conversation context window',
    icon: 'MessageCircle',
    capacity: '50K entries',
    used: '1,203 entries',
    entries: [
      { id: 'ch-1', content: '[Alex → #sre-alerts] @Alex what\'s the status on node-07?', timestamp: new Date(Date.now() - 600000), tags: ['message', 'query'] },
      { id: 'ch-2', content: '[Alex] Investigating now — seeing 94% CPU utilization. Running diagnostics.', timestamp: new Date(Date.now() - 540000), tags: ['response'] },
      { id: 'ch-3', content: '[Alex → #sre-alerts] Update: Found potential memory leak in payment-service v2.4.1. Requesting rollback approval.', timestamp: new Date(Date.now() - 300000), tags: ['update', 'escalation'] },
    ],
  },
  {
    tier: 2,
    name: 'Episodic Memory',
    desc: 'Semantic vector store of past experiences and outcomes',
    icon: 'Brain',
    capacity: '100K episodes',
    used: '847 episodes',
    entries: [
      { id: 'ep-1', content: 'INC-4201: Similar CPU spike on node-03 in Jan 2026. Root cause: Redis connection pool leak after deployment. Fixed by rolling back and patching connection timeout.', timestamp: new Date(Date.now() - 86400000 * 7), relevance: 0.94, tags: ['incident', 'kubernetes', 'cpu'] },
      { id: 'ep-2', content: 'INC-3891: payment-service v2.3.0 caused OOMKilled events in Nov 2025. Rollback procedure: kubectl rollout undo deployment/payment-service', timestamp: new Date(Date.now() - 86400000 * 45), relevance: 0.89, tags: ['payment-service', 'oom', 'rollback'] },
      { id: 'ep-3', content: 'Prod deployment runbook: Always drain nodes before maintenance. Use kubectl drain --ignore-daemonsets --delete-emptydir-data', timestamp: new Date(Date.now() - 86400000 * 90), relevance: 0.76, tags: ['runbook', 'kubernetes'] },
    ],
  },
  {
    tier: 3,
    name: 'Entity Memory',
    desc: 'Structured knowledge graph of people, systems, and projects',
    icon: 'Network',
    capacity: 'Unlimited',
    used: '234 entities',
    entries: [
      { id: 'en-1', content: 'System: prod-k8s-node-07 | Type: Kubernetes node | Cluster: prod-us-east | Last incident: 2026-02-15 | Owner: SRE team', timestamp: new Date(Date.now() - 86400000), tags: ['system', 'kubernetes'] },
      { id: 'en-2', content: 'Service: payment-service | Team: Payments | SLA: 99.95% | On-call: sarah.chen@corp.com | Repo: github.com/corp/payment-service', timestamp: new Date(Date.now() - 86400000 * 3), tags: ['service', 'payments'] },
      { id: 'en-3', content: 'Person: john.smith@corp.com | Role: Senior Engineer | Team: SRE | PagerDuty rotation: primary | Slack: @jsmith', timestamp: new Date(Date.now() - 86400000 * 5), tags: ['person', 'sre'] },
    ],
  },
  {
    tier: 4,
    name: 'Shared Knowledge Base',
    desc: 'Org-wide indexed documentation and runbooks',
    icon: 'BookOpen',
    capacity: '1M documents',
    used: '8,432 documents',
    entries: [
      { id: 'kb-1', content: 'Runbook: Kubernetes Node Drain Procedure v3.2 | Tags: kubernetes, ops, drain | Last updated: 2026-02-01', timestamp: new Date(Date.now() - 86400000 * 10), tags: ['runbook', 'kubernetes'] },
      { id: 'kb-2', content: 'Policy: Production Change Management — All P1 changes require CTO approval. Rollbacks exempt if time-critical.', timestamp: new Date(Date.now() - 86400000 * 30), tags: ['policy', 'change-mgmt'] },
      { id: 'kb-3', content: 'Architecture Doc: Payment Service v2.x Architecture — microservice, 3 replicas, Redis session cache, Postgres primary', timestamp: new Date(Date.now() - 86400000 * 60), tags: ['architecture', 'payment'] },
    ],
  },
];

export const OPA_POLICIES = `# Project Talon — OPA Policy Configuration
# Version: 2.0 | Last updated: 2026-02-25

package talon.policy

# ─────────────────────────────────────────────────────────────
# PRODUCTION DEPLOYMENT POLICY
# ─────────────────────────────────────────────────────────────
deny[msg] {
  input.action == "kubectl.apply"
  input.namespace == "production"
  not input.hitl_approved
  msg := "Production deployments require HITL approval"
}

deny[msg] {
  input.action == "kubectl.drain"
  input.environment == "prod"
  not input.supervisor_approved
  msg := "Node drain in prod requires supervisor approval"
}

# ─────────────────────────────────────────────────────────────
# EMAIL BULK SEND POLICY  
# ─────────────────────────────────────────────────────────────
deny[msg] {
  input.action == "email.send"
  count(input.recipients) > 20
  not input.email_approved
  msg := "Bulk email to >20 recipients requires approval"
}

deny[msg] {
  input.action == "email.send"
  input.recipients[_] matches "@external.com$"
  not input.data_classification_check
  msg := "External email requires data classification check"
}

# ─────────────────────────────────────────────────────────────
# SHELL EXECUTION POLICY
# ─────────────────────────────────────────────────────────────
deny[msg] {
  input.action == "shell.exec"
  input.sandbox_profile == "minimal"
  msg := "Shell execution not permitted in minimal sandbox"
}

allow[sandbox] {
  input.action == "shell.exec"
  input.agent_id == "alex"
  sandbox := "compute"
}

# ─────────────────────────────────────────────────────────────
# DATA EXPORT POLICY
# ─────────────────────────────────────────────────────────────
deny[msg] {
  input.action == "data.export"
  input.classification in ["confidential", "restricted"]
  not input.compliance_approved
  msg := "Confidential data export requires compliance approval"
}

# ─────────────────────────────────────────────────────────────
# FIREWALL POLICY
# ─────────────────────────────────────────────────────────────
deny[msg] {
  input.action == "firewall.block"
  not input.security_team_approved
  msg := "Firewall changes require security team approval"
}`;

export function generateTimeSeriesData(points: number, baseValue: number, variance: number) {
  const data = [];
  const now = new Date();
  for (let i = points - 1; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 5 * 60 * 1000);
    data.push({
      time: `${time.getHours().toString().padStart(2, '0')}:${time.getMinutes().toString().padStart(2, '0')}`,
      value: Math.max(0, baseValue + (Math.random() - 0.5) * variance * 2),
    });
  }
  return data;
}
