import { useState } from 'react';
import { RefreshCw, MessageSquare, Layers, Cpu, Hash } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader } from '../components/UI';
import ReactLoopViz from '../components/ReactLoopViz';

const SOURCES = [
  { name: 'MS Teams', icon: '💬', color: '#5b5ea6', messages: 12 },
  { name: 'Slack', icon: '⚡', color: '#4a154b', messages: 8 },
  { name: 'Email', icon: '📧', color: '#1a73e8', messages: 5 },
  { name: 'PagerDuty', icon: '🚨', color: '#25a642', messages: 3 },
];

export default function ReActLoop() {
  const { employees } = useApp();
  const [selectedId, setSelectedId] = useState(employees[0]?.id || 'alex');
  const emp = employees.find(e => e.id === selectedId) || employees[0];

  if (!emp) return null;

  const iteration = Math.floor(Date.now() / 10000) % 200 + 40;
  const tokenUsage = emp.tokensUsed;
  const toolCalls = Math.floor(iteration * 2.3);

  return (
    <div>
      <PageHeader title="ReAct Loop Visualizer" subtitle="Real-time view of the persistent reasoning engine" />

      {/* Employee selector */}
      <div className="flex flex-wrap gap-2 mb-6">
        {employees.map(e => (
          <button
            key={e.id}
            onClick={() => setSelectedId(e.id)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all border ${
              selectedId === e.id
                ? `border-current`
                : 'border-slate-700 text-slate-400 bg-slate-800 hover:bg-slate-700'
            }`}
            style={selectedId === e.id ? { color: e.color, backgroundColor: `${e.color}20`, borderColor: `${e.color}50` } : {}}
          >
            <span>{e.emoji}</span>
            <span>{e.name}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Main visualizer */}
        <div className="xl:col-span-2 space-y-4">
          {/* Input sources */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-blue-400" /> Input Sources
            </h3>
            <div className="flex flex-wrap gap-3">
              {SOURCES.map(src => (
                <div key={src.name} className="flex items-center gap-2 px-3 py-2 rounded-lg border border-slate-600/30 bg-slate-700/30">
                  <span>{src.icon}</span>
                  <span className="text-sm text-slate-300">{src.name}</span>
                  <span className="px-1.5 py-0.5 rounded text-xs bg-slate-600 text-slate-300">{src.messages}</span>
                  {/* Animated pulse for active */}
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                </div>
              ))}
            </div>
          </div>

          {/* ReAct Loop */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin" style={{ color: emp.color }} />
              Persistent ReAct Loop — {emp.name} ({emp.role})
            </h3>
            <ReactLoopViz
              employeeId={emp.id}
              reactState={emp.reactState}
              currentTask={emp.currentTask}
              color={emp.color}
            />
          </div>

          {/* Current loop state details */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" /> Loop State Details
            </h3>
            <div className="space-y-3">
              {[
                { phase: 'Perceive', detail: `Reading ${SOURCES.reduce((a, s) => a + s.messages, 0)} pending messages from Teams, Slack, Email, PagerDuty`, active: emp.reactState === 'perceive' },
                { phase: 'Plan', detail: 'Retrieving 3 relevant runbooks from KB. Forming 4-step action plan.', active: emp.reactState === 'plan' },
                { phase: 'Act', detail: `Executing: kubectl top node prod-k8s-node-07 (sandbox: compute, timeout: 30s)`, active: emp.reactState === 'act' },
                { phase: 'Observe', detail: 'Tool returned: CPU=94%, Memory=87%. Pod events: 3x OOMKilled in 60min.', active: emp.reactState === 'observe' },
                { phase: 'Decide', detail: 'Decision: Root cause identified. Plan: Request HITL approval for node drain.', active: emp.reactState === 'decide' },
              ].map(item => (
                <div
                  key={item.phase}
                  className={`flex items-start gap-3 p-3 rounded-lg border transition-all duration-500 ${
                    item.active
                      ? 'border-current bg-opacity-10'
                      : 'border-slate-700/30 bg-slate-800/20 opacity-50'
                  }`}
                  style={item.active ? { borderColor: `${emp.color}50`, backgroundColor: `${emp.color}10` } : {}}
                >
                  <div
                    className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${item.active ? 'animate-pulse' : ''}`}
                    style={{ backgroundColor: item.active ? emp.color : '#475569' }}
                  />
                  <div>
                    <span className="text-xs font-semibold text-slate-300">{item.phase}: </span>
                    <span className="text-xs text-slate-400">{item.detail}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right panel — stats */}
        <div className="space-y-4">
          {/* Loop stats */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-green-400" /> Loop Statistics
            </h3>
            <div className="space-y-3">
              {[
                { label: 'Iteration', value: `#${iteration}`, color: emp.color },
                { label: 'Token Usage', value: `${(tokenUsage / 1000).toFixed(1)}K`, color: '#a855f7' },
                { label: 'Tool Calls', value: toolCalls, color: '#22c55e' },
                { label: 'Avg Loop Time', value: '2.4s', color: '#f59e0b' },
                { label: 'Checkpoints', value: Math.floor(iteration / 10), color: '#06b6d4' },
              ].map(s => (
                <div key={s.label} className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">{s.label}</span>
                  <span className="font-semibold text-sm" style={{ color: s.color }}>{s.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Checkpoint */}
          <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4">
            <h3 className="text-green-400 font-semibold text-sm mb-2 flex items-center gap-2">
              <Hash className="w-4 h-4" /> Checkpoint Status
            </h3>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-green-400" />
              <span className="text-green-300 text-xs">Last checkpoint: {Math.floor(Date.now() / 1000) % 120}s ago</span>
            </div>
            <div className="text-xs text-slate-400 font-mono bg-slate-900/50 rounded p-2 break-all">
              chk_{emp.id}_{iteration}_{Math.random().toString(36).slice(2, 10)}
            </div>
          </div>

          {/* Message queue */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm mb-3">Message Queue</h3>
            <div className="space-y-2">
              {[
                { from: '#sre-alerts', msg: 'Node-07 CPU critical', priority: 'P1' },
                { from: 'sarah.chen', msg: 'Can you check payment service?', priority: 'P2' },
                { from: 'heartbeat', msg: 'Scheduled health check', priority: 'P3' },
              ].map((m, i) => (
                <div key={i} className="flex items-start gap-2 p-2 bg-slate-700/30 rounded-lg">
                  <span className={`text-xs px-1.5 py-0.5 rounded font-bold ${
                    m.priority === 'P1' ? 'bg-red-500/20 text-red-400' :
                    m.priority === 'P2' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-slate-500/20 text-slate-400'
                  }`}>{m.priority}</span>
                  <div>
                    <div className="text-xs text-slate-400">{m.from}</div>
                    <div className="text-xs text-slate-300">{m.msg}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
