import { useState } from 'react';
import { Brain, Zap, MessageCircle, Network, BookOpen, Search, HardDrive } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader } from '../components/UI';
import { MEMORY_TIERS } from '../data/mockData';

const TIER_ICONS = [Zap, MessageCircle, Brain, Network, BookOpen];

export default function MemoryExplorer() {
  const { employees } = useApp();
  const [selectedTier, setSelectedTier] = useState(0);
  const [selectedEmployee, setSelectedEmployee] = useState('alex');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<typeof MEMORY_TIERS[0]['entries']>([]);
  const [searching, setSearching] = useState(false);

  const tier = MEMORY_TIERS[selectedTier];
  const emp = employees.find(e => e.id === selectedEmployee) || employees[0];

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setSearching(true);
    await new Promise(r => setTimeout(r, 800));
    const results = MEMORY_TIERS.flatMap(t => t.entries).filter(e =>
      e.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.tags.some(tag => tag.includes(searchQuery.toLowerCase()))
    );
    setSearchResults(results);
    setSearching(false);
  };

  const filteredEntries = searchQuery && searchResults.length > 0 ? searchResults : tier.entries;

  return (
    <div>
      <PageHeader title="Memory Explorer" subtitle="Explore the 5-tier persistent memory architecture" />

      {/* Employee selector */}
      <div className="flex flex-wrap gap-2 mb-6">
        {employees.map(e => (
          <button
            key={e.id}
            onClick={() => setSelectedEmployee(e.id)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all border ${
              selectedEmployee === e.id
                ? `border-current`
                : 'border-slate-700 text-slate-400 bg-slate-800 hover:bg-slate-700'
            }`}
            style={selectedEmployee === e.id ? { color: e.color, backgroundColor: `${e.color}20`, borderColor: `${e.color}50` } : {}}
          >
            <span>{e.emoji}</span>
            <span>{e.name}</span>
          </button>
        ))}
      </div>

      {/* Memory stats overview */}
      <div className="grid grid-cols-3 md:grid-cols-5 gap-3 mb-6">
        {MEMORY_TIERS.map((t, idx) => {
          const Icon = TIER_ICONS[idx];
          return (
            <button
              key={t.tier}
              onClick={() => setSelectedTier(idx)}
              className={`p-3 rounded-xl border text-left transition-all ${
                selectedTier === idx
                  ? 'bg-blue-600/20 border-blue-500/50 text-blue-400'
                  : 'bg-slate-800/50 border-slate-700/50 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4 mb-2" />
              <div className="text-xs font-semibold">Tier {t.tier}</div>
              <div className="text-xs opacity-70 truncate">{t.name}</div>
              <div className="text-xs mt-1 font-mono opacity-50">{t.used}</div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Tier detail */}
        <div className="xl:col-span-3 space-y-4">
          {/* Tier header */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h2 className="text-white font-bold text-lg">Tier {tier.tier}: {tier.name}</h2>
                <p className="text-slate-400 text-sm">{tier.desc}</p>
              </div>
              <div className="text-right">
                <div className="text-slate-400 text-xs">Capacity</div>
                <div className="text-white font-semibold text-sm">{tier.capacity}</div>
                <div className="text-slate-400 text-xs">Used: {tier.used}</div>
              </div>
            </div>

            {/* Search bar (tier 2+) */}
            {selectedTier >= 2 && (
              <div className="flex gap-2">
                <div className="flex-1 flex items-center gap-2 bg-slate-900/50 border border-slate-600/50 rounded-lg px-3 py-2">
                  <Search className="w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleSearch()}
                    placeholder="Semantic search..."
                    className="bg-transparent text-slate-300 text-sm flex-1 outline-none placeholder-slate-500"
                  />
                </div>
                <button
                  onClick={handleSearch}
                  disabled={searching}
                  className="px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {searching ? '...' : 'Search'}
                </button>
              </div>
            )}
          </div>

          {/* Memory entries */}
          <div className="space-y-3">
            {filteredEntries.map(entry => (
              <div key={entry.id} className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4 hover:border-slate-600 transition-colors">
                <div className="flex items-start justify-between gap-4 mb-2">
                  <p className="text-slate-200 text-sm leading-relaxed flex-1">{entry.content}</p>
                  {entry.relevance !== undefined && (
                    <div className="flex-shrink-0 text-right">
                      <div className="text-xs text-slate-500">Relevance</div>
                      <div className="text-green-400 font-semibold text-sm">{(entry.relevance * 100).toFixed(0)}%</div>
                    </div>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex flex-wrap gap-1">
                    {entry.tags.map(tag => (
                      <span key={tag} className="px-1.5 py-0.5 rounded text-xs bg-slate-700/50 text-slate-400 border border-slate-600/30">
                        #{tag}
                      </span>
                    ))}
                  </div>
                  <span className="text-xs text-slate-500">{entry.timestamp.toLocaleDateString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right panel — stats */}
        <div className="space-y-4">
          {/* Employee memory stats */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
              <Brain className="w-4 h-4 text-purple-400" />
              {emp?.name}'s Memory
            </h3>
            <div className="space-y-3">
              {[
                { label: 'Episodic Memories', value: emp?.episodicMemories || 0, color: '#a855f7' },
                { label: 'Entity Records', value: emp?.entityRecords || 0, color: '#3b82f6' },
                { label: 'KB Hits Today', value: emp?.kbHits || 0, color: '#22c55e' },
              ].map(s => (
                <div key={s.label}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-400">{s.label}</span>
                    <span className="text-slate-200 font-medium">{s.value.toLocaleString()}</span>
                  </div>
                  <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${Math.min(100, (s.value / 2000) * 100)}%`, backgroundColor: s.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Storage breakdown */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-blue-400" /> Storage Usage
            </h3>
            <div className="space-y-2">
              {MEMORY_TIERS.map((t, idx) => {
                const Icon = TIER_ICONS[idx];
                const pct = [34, 15, 28, 12, 11][idx];
                return (
                  <div key={t.tier} className="flex items-center gap-2">
                    <Icon className="w-3 h-3 text-slate-400 flex-shrink-0" />
                    <div className="flex-1">
                      <div className="flex justify-between text-xs mb-0.5">
                        <span className="text-slate-400">T{t.tier}</span>
                        <span className="text-slate-300">{pct}%</span>
                      </div>
                      <div className="h-1 bg-slate-700 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
