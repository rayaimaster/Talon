import { useState } from 'react';
import { ClipboardList, Search, Filter, Download, Play, CheckCircle, XCircle, Hash } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader, RiskBadge } from '../components/UI';
import { AuditEvent } from '../types';

const EVENT_TYPE_ICONS: Record<string, string> = {
  'tool.invoked': '⚙️',
  'shell.executed': '💻',
  'hitl.requested': '🙋',
  'email.sent': '📧',
  'memory.stored': '🧠',
  'api.called': '🔗',
  'browser.action': '🌐',
  'file.written': '📝',
  'escalation.triggered': '🚨',
  'checkpoint.saved': '💾',
  'delegation.started': '🤝',
};

function EventRow({ event, onReplay }: { event: AuditEvent; onReplay: (e: AuditEvent) => void }) {
  const empColor = {
    alex: 'text-blue-400',
    dana: 'text-green-400',
    morgan: 'text-purple-400',
    casey: 'text-orange-400',
    jordan: 'text-yellow-400',
  }[event.employeeId] || 'text-slate-400';

  const outcomeDisplay = {
    success: { class: 'text-green-400', icon: '✓' },
    failure: { class: 'text-red-400', icon: '✗' },
    pending: { class: 'text-yellow-400', icon: '⏳' },
    rejected: { class: 'text-red-400', icon: '✗' },
  }[event.outcome];

  return (
    <div className="flex items-start gap-3 p-3 hover:bg-slate-700/20 rounded-lg transition-colors border-b border-slate-700/20">
      <div className="flex-shrink-0 text-lg mt-0.5">
        {EVENT_TYPE_ICONS[event.eventType] || '📋'}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start flex-wrap gap-2 mb-1">
          <span className={`text-xs font-medium ${empColor}`}>{event.employeeName}</span>
          <span className="text-xs text-slate-400 font-mono bg-slate-700/50 px-1.5 py-0.5 rounded">{event.eventType}</span>
          <RiskBadge level={event.riskLevel} />
          <span className={`text-xs font-medium ${outcomeDisplay.class}`}>
            {outcomeDisplay.icon} {event.outcome}
          </span>
        </div>
        <p className="text-sm text-slate-200 mb-1">{event.action}</p>
        <p className="text-xs text-slate-500">{event.detail}</p>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-xs text-slate-500 font-mono">{event.timestamp.toLocaleString()}</span>
          <span className="text-xs text-slate-600 font-mono">#{event.hash.slice(0, 8)}</span>
        </div>
      </div>
      <button
        onClick={() => onReplay(event)}
        className="flex-shrink-0 p-1.5 rounded-lg text-slate-400 hover:text-blue-400 hover:bg-blue-500/10 transition-colors"
        title="Replay"
      >
        <Play className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

function ReplayModal({ event, onClose }: { event: AuditEvent; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
        <h3 className="text-white font-bold mb-4 flex items-center gap-2">
          <Play className="w-4 h-4 text-blue-400" /> Event Replay
        </h3>
        <div className="space-y-3">
          <div className="bg-slate-800/50 rounded-lg p-4 font-mono text-xs space-y-2">
            <div className="text-slate-400">Event ID: <span className="text-slate-200">{event.id}</span></div>
            <div className="text-slate-400">Timestamp: <span className="text-slate-200">{event.timestamp.toISOString()}</span></div>
            <div className="text-slate-400">Agent: <span className="text-blue-400">{event.employeeName}</span></div>
            <div className="text-slate-400">Type: <span className="text-slate-200">{event.eventType}</span></div>
            <div className="text-slate-400">Action: <span className="text-slate-200">{event.action}</span></div>
            <div className="text-slate-400">Detail: <span className="text-slate-200">{event.detail}</span></div>
            <div className="text-slate-400">Risk: <span className="text-orange-400">{event.riskLevel.toUpperCase()}</span></div>
            <div className="text-slate-400">Outcome: <span className="text-green-400">{event.outcome}</span></div>
            <div className="text-slate-400">Hash: <span className="text-slate-200">{event.hash}</span></div>
          </div>
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
            <span className="text-green-400 text-xs">Hash chain integrity verified — event untampered</span>
          </div>
        </div>
        <button onClick={onClose} className="mt-4 w-full py-2 rounded-lg bg-slate-700 text-slate-300 text-sm hover:bg-slate-600">
          Close
        </button>
      </div>
    </div>
  );
}

export default function AuditTrail() {
  const { auditEvents } = useApp();
  const [search, setSearch] = useState('');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [replayEvent, setReplayEvent] = useState<AuditEvent | null>(null);

  const filtered = auditEvents.filter(e => {
    const matchSearch = !search || e.action.toLowerCase().includes(search.toLowerCase()) ||
      e.employeeName.toLowerCase().includes(search.toLowerCase()) ||
      e.eventType.includes(search.toLowerCase());
    const matchRisk = riskFilter === 'all' || e.riskLevel === riskFilter;
    const matchType = typeFilter === 'all' || e.eventType === typeFilter;
    return matchSearch && matchRisk && matchType;
  });

  const uniqueTypes = ['all', ...Array.from(new Set(auditEvents.map(e => e.eventType)))];

  return (
    <div>
      <PageHeader title="Audit Trail" subtitle="Immutable, tamper-evident log of all agent actions" />

      {/* Hash chain indicator */}
      <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-3 mb-6 flex items-center gap-3">
        <Hash className="w-4 h-4 text-green-400 flex-shrink-0" />
        <div>
          <span className="text-green-400 text-sm font-medium">Hash Chain Integrity: VERIFIED</span>
          <span className="text-slate-400 text-xs ml-2">All {auditEvents.length} events verified • Last block: {new Date().toLocaleTimeString()}</span>
        </div>
        <button className="ml-auto flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-700 text-slate-300 text-sm hover:bg-slate-600">
          <Download className="w-3.5 h-3.5" /> Export
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="flex items-center gap-2 bg-slate-800/50 border border-slate-700/50 rounded-lg px-3 py-2 flex-1 min-w-0">
          <Search className="w-4 h-4 text-slate-400 flex-shrink-0" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search events..."
            className="bg-transparent text-slate-300 text-sm flex-1 outline-none placeholder-slate-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={riskFilter}
            onChange={e => setRiskFilter(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-slate-300 text-sm rounded-lg px-3 py-2 outline-none"
          >
            <option value="all">All Risks</option>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="critical">Critical</option>
          </select>
          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-slate-300 text-sm rounded-lg px-3 py-2 outline-none"
          >
            {uniqueTypes.map(t => (
              <option key={t} value={t}>{t === 'all' ? 'All Types' : t}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex items-center justify-between mb-3">
        <span className="text-slate-400 text-sm">{filtered.length} events</span>
        <div className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
          <span className="text-xs text-slate-400">Auto-updating</span>
        </div>
      </div>

      {/* Event list */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
        <div className="divide-y divide-slate-700/20">
          {filtered.length === 0 ? (
            <div className="p-8 text-center text-slate-400">No events match your filters</div>
          ) : (
            filtered.map(event => (
              <EventRow key={event.id} event={event} onReplay={setReplayEvent} />
            ))
          )}
        </div>
      </div>

      {replayEvent && <ReplayModal event={replayEvent} onClose={() => setReplayEvent(null)} />}
    </div>
  );
}
