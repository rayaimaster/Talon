import { useState } from 'react';
import { Terminal, Globe, MessageSquare, FileText, Boxes, Database, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import { PageHeader } from '../components/UI';
import { TOOL_CATEGORIES, SANDBOX_PROFILES } from '../data/mockData';
import { useApp } from '../context/AppContext';

const CAT_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  compute: Terminal,
  browser: Globe,
  communication: MessageSquare,
  files: FileText,
  saas: Boxes,
  data: Database,
};

const CAT_COLORS: Record<string, string> = {
  compute: 'blue',
  browser: 'green',
  communication: 'purple',
  files: 'orange',
  saas: 'yellow',
  data: 'red',
};

const STATUS_DISPLAY: Record<string, { icon: React.ComponentType<{ className?: string }>, class: string, label: string }> = {
  available: { icon: CheckCircle, class: 'text-green-400', label: 'Available' },
  'in-use': { icon: Clock, class: 'text-blue-400', label: 'In Use' },
  'rate-limited': { icon: AlertCircle, class: 'text-yellow-400', label: 'Rate Limited' },
  error: { icon: AlertCircle, class: 'text-red-400', label: 'Error' },
};

// Simulated execution log
const EXEC_LOG = [
  { time: '05:14:32', emp: 'Alex', tool: 'kubectl', cmd: 'kubectl top node prod-k8s-node-07', status: 'success', duration: '1.2s' },
  { time: '05:14:28', emp: 'Morgan', tool: 'Snowflake', cmd: 'SELECT * FROM revenue_facts WHERE date >= \'2026-01-01\'', status: 'success', duration: '3.4s' },
  { time: '05:14:21', emp: 'Dana', tool: 'Okta', cmd: 'POST /api/v1/users/john.smith/lifecycle/resetPassword', status: 'success', duration: '0.8s' },
  { time: '05:14:15', emp: 'Casey', tool: 'Splunk SIEM', cmd: 'index=security sourcetype=firewall action=blocked | stats count by src_ip', status: 'success', duration: '4.1s' },
  { time: '05:14:08', emp: 'Jordan', tool: 'Jira', cmd: 'POST /rest/api/3/issue — Create sprint planning ticket', status: 'success', duration: '0.6s' },
  { time: '05:13:57', emp: 'Alex', tool: 'PagerDuty', cmd: 'POST /incidents — Trigger P1 for node CPU alert', status: 'success', duration: '0.4s' },
  { time: '05:13:45', emp: 'Morgan', tool: 'Python', cmd: 'python3 forecast_model.py --quarters Q1 Q2 --output /tmp/forecast.csv', status: 'success', duration: '12.3s' },
  { time: '05:13:30', emp: 'Dana', tool: 'ServiceNow', cmd: 'PATCH /table/incident/INC0123456 — resolve ticket', status: 'success', duration: '1.1s' },
];

export default function ToolFramework() {
  const { activityFeed } = useApp();
  const [selectedCategory, setSelectedCategory] = useState('compute');

  const cat = TOOL_CATEGORIES.find(c => c.id === selectedCategory) || TOOL_CATEGORIES[0];
  const color = CAT_COLORS[cat.id];

  const colorMap: Record<string, string> = {
    blue: 'border-blue-500/40 bg-blue-500/10 text-blue-400',
    green: 'border-green-500/40 bg-green-500/10 text-green-400',
    purple: 'border-purple-500/40 bg-purple-500/10 text-purple-400',
    orange: 'border-orange-500/40 bg-orange-500/10 text-orange-400',
    yellow: 'border-yellow-500/40 bg-yellow-500/10 text-yellow-400',
    red: 'border-red-500/40 bg-red-500/10 text-red-400',
  };

  return (
    <div>
      <PageHeader title="Tool & Agency Framework" subtitle="All agent capabilities, tools, and sandbox environments" />

      {/* Category tabs */}
      <div className="grid grid-cols-3 lg:grid-cols-6 gap-2 mb-6">
        {TOOL_CATEGORIES.map(cat => {
          const Icon = CAT_ICONS[cat.id];
          const c = CAT_COLORS[cat.id];
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`p-3 rounded-xl border text-left transition-all ${
                isSelected ? colorMap[c] : 'bg-slate-800/50 border-slate-700/50 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <Icon className="w-5 h-5 mb-2" />
              <div className="text-xs font-semibold leading-tight">{cat.name}</div>
              <div className="text-xs opacity-60 mt-1">{cat.tools.length} tools</div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
          {/* Tool grid */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              {(() => { const Icon = CAT_ICONS[cat.id]; return <Icon className="w-4 h-4" />; })()}
              {cat.name}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {cat.tools.map((tool: { name: string; status: string; usageCount: number }) => {
                const statusInfo = STATUS_DISPLAY[tool.status] || STATUS_DISPLAY.available;
                const StatusIcon = statusInfo.icon;
                return (
                  <div key={tool.name} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg border border-slate-600/20">
                    <div className="flex items-center gap-3">
                      <StatusIcon className={`w-4 h-4 ${statusInfo.class}`} />
                      <div>
                        <div className="text-white text-sm font-medium">{tool.name}</div>
                        <div className="text-slate-500 text-xs">{tool.usageCount} calls today</div>
                      </div>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full border ${
                      tool.status === 'available' ? 'bg-green-500/10 text-green-400 border-green-500/20' :
                      tool.status === 'in-use' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' :
                      'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                    }`}>{statusInfo.label}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Sandbox profiles table */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <h3 className="text-white font-semibold mb-4">Sandbox Profiles</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-slate-400 text-xs uppercase tracking-wider">
                    <th className="text-left pb-3 pr-4">Profile</th>
                    <th className="text-left pb-3 pr-4">Network</th>
                    <th className="text-left pb-3 pr-4">Filesystem</th>
                    <th className="text-left pb-3 pr-4">Processes</th>
                    <th className="text-left pb-3">Use Case</th>
                  </tr>
                </thead>
                <tbody className="space-y-2">
                  {SANDBOX_PROFILES.map(p => (
                    <tr key={p.name} className="border-t border-slate-700/30">
                      <td className="py-2.5 pr-4">
                        <span className="px-2 py-0.5 rounded-lg bg-slate-700 text-slate-200 text-xs font-mono">{p.name}</span>
                      </td>
                      <td className="py-2.5 pr-4 text-slate-300 text-xs">
                        {typeof p.network === 'boolean' ? (p.network ? '✓ Yes' : '✗ No') : p.network}
                      </td>
                      <td className="py-2.5 pr-4 text-slate-300 text-xs">{p.filesystem}</td>
                      <td className="py-2.5 pr-4 text-slate-300 text-xs">{p.processes}</td>
                      <td className="py-2.5 text-slate-400 text-xs">{p.useCase}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Live execution log */}
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4 flex flex-col">
          <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-green-400" /> Live Execution Log
            <span className="ml-auto flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="text-xs text-slate-400">Live</span>
            </span>
          </h3>
          <div className="flex-1 overflow-y-auto space-y-2 font-mono text-xs">
            {/* Live events first */}
            {activityFeed.filter(e => e.type === 'tool').slice(0, 5).map(ev => (
              <div key={ev.id} className="p-2 bg-slate-900/50 rounded border border-slate-700/30">
                <div className="text-slate-400">[{ev.timestamp.toLocaleTimeString()}] <span className={
                  ev.employeeId === 'alex' ? 'text-blue-400' :
                  ev.employeeId === 'dana' ? 'text-green-400' :
                  ev.employeeId === 'morgan' ? 'text-purple-400' :
                  ev.employeeId === 'casey' ? 'text-orange-400' : 'text-yellow-400'
                }>{ev.employeeName}</span></div>
                <div className="text-green-300 mt-0.5 truncate">{ev.action}</div>
              </div>
            ))}
            {EXEC_LOG.map((log, i) => (
              <div key={i} className="p-2 bg-slate-900/50 rounded border border-slate-700/30">
                <div className="text-slate-500">[{log.time}] <span className="text-slate-300">{log.emp}</span> via {log.tool}</div>
                <div className="text-green-300 mt-0.5 truncate" title={log.cmd}>{log.cmd}</div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-green-400">✓ {log.status}</span>
                  <span className="text-slate-500">{log.duration}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
