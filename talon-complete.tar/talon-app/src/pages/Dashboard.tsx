import { useEffect, useRef } from 'react';
import { Users, MessageSquare, CheckCircle, Clock, Zap, DollarSign, Activity, Cpu, HardDrive, Globe } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MetricCard, StatusBadge, PageHeader } from '../components/UI';
import { DigitalEmployee } from '../types';

const typeColors: Record<string, string> = {
  tool: 'text-blue-400',
  message: 'text-green-400',
  proactive: 'text-purple-400',
  escalation: 'text-red-400',
  memory: 'text-yellow-400',
  delegation: 'text-orange-400',
};

const typeIcons: Record<string, string> = {
  tool: '⚙️',
  message: '💬',
  proactive: '⚡',
  escalation: '🚨',
  memory: '🧠',
  delegation: '🤝',
};

function EmployeeCard({ emp }: { emp: DigitalEmployee }) {
  return (
    <div className={`bg-slate-800/50 border ${emp.borderClass} rounded-xl p-4 hover:bg-slate-800 transition-all duration-200`}>
      <div className="flex items-start gap-3 mb-3">
        <div className={`w-10 h-10 rounded-xl ${emp.bgClass} flex items-center justify-center text-xl flex-shrink-0`}>
          {emp.emoji}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-semibold text-white text-sm">{emp.name}</h3>
            <StatusBadge status={emp.status} />
          </div>
          <p className={`text-xs ${emp.colorClass} font-medium`}>{emp.role}</p>
        </div>
      </div>
      <p className="text-xs text-slate-400 mb-3 line-clamp-2 min-h-[2rem]">{emp.currentTask}</p>
      <div className="grid grid-cols-3 gap-2 text-center">
        <div>
          <div className="text-white font-semibold text-sm">{emp.conversationsToday}</div>
          <div className="text-slate-500 text-xs">Convos</div>
        </div>
        <div>
          <div className="text-white font-semibold text-sm">{emp.completionRate}%</div>
          <div className="text-slate-500 text-xs">Complete</div>
        </div>
        <div>
          <div className="text-white font-semibold text-sm">{emp.escalationRate}%</div>
          <div className="text-slate-500 text-xs">Escalate</div>
        </div>
      </div>
      <div className="mt-3 pt-3 border-t border-slate-700/50">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full flex-shrink-0`} style={{ backgroundColor: emp.color }} />
          <div className="flex-1 h-1.5 bg-slate-700 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-1000"
              style={{ width: `${emp.completionRate}%`, backgroundColor: emp.color }}
            />
          </div>
          <span className="text-xs text-slate-400">{emp.reactState}</span>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { employees, activityFeed, globalMetrics, systemHealth } = useApp();
  const feedRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (feedRef.current) {
      feedRef.current.scrollTop = 0;
    }
  }, [activityFeed.length]);

  const activeCount = employees.filter(e => e.status === 'active').length;
  const idleCount = employees.filter(e => e.status === 'idle').length;
  const pausedCount = employees.filter(e => e.status === 'paused').length;

  return (
    <div>
      <PageHeader
        title="Platform Dashboard"
        subtitle="Project Talon — Enterprise Agentic Framework v2.0"
      />

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
        <MetricCard
          title="Digital Employees"
          value={employees.length}
          subtitle={`${activeCount} active · ${idleCount} idle · ${pausedCount} paused`}
          icon={<Users className="w-5 h-5" />}
          color="blue"
        />
        <MetricCard
          title="Messages Today"
          value={globalMetrics.totalMessages.toLocaleString()}
          icon={<MessageSquare className="w-5 h-5" />}
          color="green"
          change="14% vs yesterday"
          changePositive
        />
        <MetricCard
          title="Tasks Completed"
          value={globalMetrics.tasksCompleted}
          icon={<CheckCircle className="w-5 h-5" />}
          color="purple"
          change={`${globalMetrics.tasksChange}% vs yesterday`}
          changePositive
        />
        <MetricCard
          title="Avg Response"
          value={`${globalMetrics.avgResponseTime.toFixed(1)}s`}
          icon={<Clock className="w-5 h-5" />}
          color="yellow"
        />
        <MetricCard
          title="Proactive Tasks"
          value={globalMetrics.proactiveFired}
          icon={<Zap className="w-5 h-5" />}
          color="orange"
          change="8 new today"
          changePositive
        />
        <MetricCard
          title="Total Cost Today"
          value={`$${globalMetrics.totalCost.toFixed(2)}`}
          icon={<DollarSign className="w-5 h-5" />}
          color="red"
          subtitle="of $50.00 budget"
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
        {/* Activity Feed */}
        <div className="xl:col-span-1 bg-slate-800/50 border border-slate-700/50 rounded-xl p-4 flex flex-col" style={{ height: '420px' }}>
          <div className="flex items-center gap-2 mb-4 flex-shrink-0">
            <Activity className="w-4 h-4 text-blue-400" />
            <h2 className="text-white font-semibold text-sm">Live Activity Feed</h2>
            <span className="ml-auto flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="text-xs text-slate-400">Live</span>
            </span>
          </div>
          <div ref={feedRef} className="flex-1 overflow-y-auto space-y-2 pr-1" style={{ scrollBehavior: 'smooth' }}>
            {activityFeed.slice(0, 40).map(event => (
              <div key={event.id} className="flex items-start gap-2 p-2 rounded-lg hover:bg-slate-700/30 transition-colors">
                <span className="text-base flex-shrink-0 mt-0.5">{typeIcons[event.type]}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className={`text-xs font-medium ${
                      event.employeeId === 'alex' ? 'text-blue-400' :
                      event.employeeId === 'dana' ? 'text-green-400' :
                      event.employeeId === 'morgan' ? 'text-purple-400' :
                      event.employeeId === 'casey' ? 'text-orange-400' : 'text-yellow-400'
                    }`}>{event.employeeName}</span>
                    <span className={`text-xs ${typeColors[event.type]}`}>[{event.type}]</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-snug">{event.action}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{event.timestamp.toLocaleTimeString()}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Employee Grid */}
        <div className="xl:col-span-2">
          <h2 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-400" />
            Digital Employee Status
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {employees.map(emp => <EmployeeCard key={emp.id} emp={emp} />)}
          </div>
        </div>
      </div>

      {/* System Health */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <h2 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-green-400" />
          System Health
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'API Availability', value: systemHealth.api, unit: '%', icon: Globe, color: 'green' },
            { label: 'Memory Systems', value: systemHealth.memory, unit: '%', icon: HardDrive, color: 'blue' },
            { label: 'Tool Framework', value: systemHealth.tools, unit: '%', icon: Cpu, color: 'purple' },
            { label: 'P95 Latency', value: systemHealth.latency, unit: 'ms', icon: Clock, color: 'yellow' },
          ].map(item => (
            <div key={item.label} className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-lg bg-${item.color}-500/20 flex items-center justify-center flex-shrink-0`}>
                <item.icon className={`w-4 h-4 text-${item.color}-400`} />
              </div>
              <div>
                <div className="text-white font-semibold">{item.value}{item.unit}</div>
                <div className="text-slate-400 text-xs">{item.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
