import { useState } from 'react';
import { Users, Pause, Play, EyeOff, Eye, Zap, X, ChevronRight, Brain, Wrench, MessageSquare, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { StatusBadge, PageHeader, RiskBadge } from '../components/UI';
import { DigitalEmployee } from '../types';
import ReactLoopViz from '../components/ReactLoopViz';

function EmployeeDetail({ emp, onClose }: { emp: DigitalEmployee; onClose: () => void }) {
  const { pauseEmployee, resumeEmployee, killEmployee } = useApp();
  const [killConfirm, setKillConfirm] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <div
        className="h-full w-full max-w-2xl bg-slate-900 border-l border-slate-700 overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className={`p-6 border-b border-slate-700 bg-gradient-to-r from-slate-900 to-slate-800`}>
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className={`w-14 h-14 rounded-2xl ${emp.bgClass} flex items-center justify-center text-3xl border ${emp.borderClass}`}>
                {emp.emoji}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">{emp.name}</h2>
                <p className={`text-sm font-medium ${emp.colorClass}`}>{emp.role}</p>
                <StatusBadge status={emp.status} />
              </div>
            </div>
            <button onClick={onClose} className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Controls */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => emp.status === 'active' ? pauseEmployee(emp.id) : resumeEmployee(emp.id)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 hover:bg-blue-600/30 text-sm font-medium transition-colors"
            >
              {emp.status === 'active' ? <><Pause className="w-4 h-4" /> Pause</> : <><Play className="w-4 h-4" /> Resume</>}
            </button>
            <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-yellow-600/20 text-yellow-400 border border-yellow-500/30 hover:bg-yellow-600/30 text-sm font-medium transition-colors">
              <EyeOff className="w-4 h-4" /> Read-Only
            </button>
            <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-purple-600/20 text-purple-400 border border-purple-500/30 hover:bg-purple-600/30 text-sm font-medium transition-colors">
              <Eye className="w-4 h-4" /> Supervised
            </button>
            {!killConfirm ? (
              <button
                onClick={() => setKillConfirm(true)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-red-600/20 text-red-400 border border-red-500/30 hover:bg-red-600/30 text-sm font-medium transition-colors"
              >
                <X className="w-4 h-4" /> Kill
              </button>
            ) : (
              <div className="flex items-center gap-1">
                <button
                  onClick={() => { killEmployee(emp.id); setKillConfirm(false); onClose(); }}
                  className="px-3 py-1.5 rounded-lg bg-red-600 text-white text-sm font-medium hover:bg-red-700"
                >Confirm Kill</button>
                <button onClick={() => setKillConfirm(false)} className="px-3 py-1.5 rounded-lg bg-slate-700 text-slate-300 text-sm">Cancel</button>
              </div>
            )}
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* ReAct Loop */}
          <div>
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
              <Zap className="w-4 h-4 text-yellow-400" /> Live ReAct Loop
            </h3>
            <ReactLoopViz employeeId={emp.id} reactState={emp.reactState} currentTask={emp.currentTask} color={emp.color} />
          </div>

          {/* Current Task */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <h3 className="text-white font-semibold mb-2 flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4 text-blue-400" /> Current Task
            </h3>
            <p className="text-slate-300 text-sm">{emp.currentTask}</p>
          </div>

          {/* Memory Stats */}
          <div>
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
              <Brain className="w-4 h-4 text-purple-400" /> Memory Stats
            </h3>
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'Episodic', value: emp.episodicMemories, color: 'purple' },
                { label: 'Entities', value: emp.entityRecords, color: 'blue' },
                { label: 'KB Hits', value: emp.kbHits, color: 'green' },
              ].map(m => (
                <div key={m.label} className={`bg-${m.color}-500/10 border border-${m.color}-500/20 rounded-lg p-3 text-center`}>
                  <div className="text-white font-bold text-lg">{m.value.toLocaleString()}</div>
                  <div className="text-slate-400 text-xs">{m.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Capabilities */}
          <div>
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2 text-sm">
              <Wrench className="w-4 h-4 text-orange-400" /> Capabilities
            </h3>
            <div className="flex flex-wrap gap-2">
              {emp.capabilities.map(cap => (
                <span key={cap} className="px-2 py-1 rounded-lg bg-slate-700/50 text-slate-300 text-xs border border-slate-600/30">{cap}</span>
              ))}
            </div>
          </div>

          {/* Tools */}
          <div>
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2 text-sm">
              <Wrench className="w-4 h-4 text-blue-400" /> Tools
            </h3>
            <div className="flex flex-wrap gap-2">
              {emp.tools.map(tool => (
                <span key={tool} className="px-2 py-1 rounded-lg bg-blue-500/10 text-blue-300 text-xs border border-blue-500/20">{tool}</span>
              ))}
            </div>
          </div>

          {/* Channels */}
          <div>
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2 text-sm">
              <MessageSquare className="w-4 h-4 text-green-400" /> Channels
            </h3>
            <div className="flex flex-wrap gap-2">
              {emp.channels.map(ch => (
                <span key={ch} className="px-2 py-1 rounded-lg bg-green-500/10 text-green-300 text-xs border border-green-500/20">{ch}</span>
              ))}
            </div>
          </div>

          {/* Metrics */}
          <div>
            <h3 className="text-white font-semibold mb-3 text-sm">Performance Metrics</h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Conversations Today', value: emp.conversationsToday },
                { label: 'Completion Rate', value: `${emp.completionRate}%` },
                { label: 'Escalation Rate', value: `${emp.escalationRate}%` },
                { label: 'Avg Response Time', value: `${emp.avgResponseTime}s` },
                { label: 'Tokens Used', value: emp.tokensUsed.toLocaleString() },
                { label: 'Cost Today', value: `$${emp.costToday.toFixed(2)}` },
              ].map(m => (
                <div key={m.label} className="bg-slate-800/50 border border-slate-700/30 rounded-lg p-3">
                  <div className="text-slate-400 text-xs mb-1">{m.label}</div>
                  <div className="text-white font-semibold">{m.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function DigitalEmployees() {
  const { employees, selectEmployee, selectedEmployeeId } = useApp();
  const [filter, setFilter] = useState<'all' | 'active' | 'idle' | 'paused'>('all');

  const filtered = employees.filter(e => filter === 'all' || e.status === filter);
  const selectedEmp = employees.find(e => e.id === selectedEmployeeId);

  return (
    <div>
      <PageHeader title="Digital Employees" subtitle="Manage and monitor all digital employee agents" />

      {/* Filters */}
      <div className="flex items-center gap-2 mb-6">
        {(['all', 'active', 'idle', 'paused'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === f ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
            }`}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
            <span className="ml-2 text-xs opacity-70">
              {f === 'all' ? employees.length : employees.filter(e => e.status === f).length}
            </span>
          </button>
        ))}
      </div>

      {/* Employee Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(emp => (
          <div
            key={emp.id}
            onClick={() => selectEmployee(emp.id)}
            className={`bg-slate-800/50 border ${emp.borderClass} rounded-xl p-5 cursor-pointer hover:bg-slate-800 transition-all duration-200 group`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl ${emp.bgClass} flex items-center justify-center text-2xl border ${emp.borderClass}`}>
                  {emp.emoji}
                </div>
                <div>
                  <h3 className="font-bold text-white">{emp.name}</h3>
                  <p className={`text-xs font-medium ${emp.colorClass}`}>{emp.role}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <StatusBadge status={emp.status} />
                <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-slate-300 transition-colors" />
              </div>
            </div>

            <p className="text-sm text-slate-400 mb-4 line-clamp-2">{emp.currentTask}</p>

            {/* ReAct state bar */}
            <div className="flex items-center gap-1 mb-4">
              {(['perceive', 'plan', 'act', 'observe', 'decide'] as const).map(state => (
                <div
                  key={state}
                  className={`flex-1 h-1 rounded-full transition-all duration-500 ${
                    emp.reactState === state ? 'opacity-100' : 'opacity-20'
                  }`}
                  style={{ backgroundColor: emp.color }}
                />
              ))}
            </div>
            <div className="text-xs text-slate-400 mb-4">
              ReAct: <span style={{ color: emp.color }} className="font-medium capitalize">{emp.reactState}</span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center border-t border-slate-700/50 pt-3">
              <div>
                <div className="text-white font-semibold text-sm">{emp.conversationsToday}</div>
                <div className="text-slate-500 text-xs">Convos</div>
              </div>
              <div>
                <div className="text-white font-semibold text-sm">{emp.completionRate}%</div>
                <div className="text-slate-500 text-xs">Complete</div>
              </div>
              <div>
                <div className="text-white font-semibold text-sm">${emp.costToday.toFixed(2)}</div>
                <div className="text-slate-500 text-xs">Cost</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Detail Panel */}
      {selectedEmp && (
        <EmployeeDetail emp={selectedEmp} onClose={() => selectEmployee(null)} />
      )}
    </div>
  );
}
