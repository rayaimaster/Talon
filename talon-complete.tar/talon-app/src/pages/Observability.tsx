import { useState, useEffect } from 'react';
import { BarChart2, AlertTriangle, TrendingUp } from 'lucide-react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend, RadialBarChart, RadialBar
} from 'recharts';
import { useApp } from '../context/AppContext';
import { PageHeader } from '../components/UI';
import { generateTimeSeriesData } from '../data/mockData';

const EMPLOYEE_COLORS = {
  Alex: '#3b82f6',
  Dana: '#22c55e',
  Morgan: '#a855f7',
  Casey: '#f97316',
  Jordan: '#eab308',
};

export default function Observability() {
  const { employees } = useApp();
  const [msgData, setMsgData] = useState(generateTimeSeriesData(24, 120, 60));
  const [tokenData, setTokenData] = useState(generateTimeSeriesData(24, 5000, 2000));
  const [latencyData, setLatencyData] = useState(generateTimeSeriesData(24, 1400, 400));

  useEffect(() => {
    const interval = setInterval(() => {
      setMsgData(generateTimeSeriesData(24, 120, 60));
      setTokenData(generateTimeSeriesData(24, 5000, 2000));
      setLatencyData(generateTimeSeriesData(24, 1400, 400));
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const tasksByEmployee = employees.map(e => ({
    name: e.name,
    tasks: e.conversationsToday,
    fill: e.color,
  }));

  const toolUsage = [
    { name: 'Jira', count: 567, fill: '#3b82f6' },
    { name: 'ServiceNow', count: 423, fill: '#22c55e' },
    { name: 'Snowflake', count: 312, fill: '#a855f7' },
    { name: 'Splunk', count: 289, fill: '#f97316' },
    { name: 'kubectl', count: 234, fill: '#eab308' },
    { name: 'Okta', count: 189, fill: '#06b6d4' },
  ];

  const costGaugeData = [{ name: 'Cost', value: (employees.reduce((a, e) => a + e.costToday, 0) / 50) * 100, fill: '#3b82f6' }];
  const completionGaugeData = [{ name: 'Completion', value: Math.round(employees.reduce((a, e) => a + e.completionRate, 0) / employees.length), fill: '#22c55e' }];

  const alerts = [
    { id: 1, severity: 'high', message: 'CPU spike detected on prod-k8s-node-07 (94%)', time: '5m ago', employee: 'Alex' },
    { id: 2, severity: 'medium', message: 'Token usage 15% above baseline for Morgan', time: '12m ago', employee: 'Morgan' },
    { id: 3, severity: 'low', message: 'Splunk query response time elevated (4.1s avg)', time: '23m ago', employee: 'Casey' },
    { id: 4, severity: 'medium', message: 'Dana escalation rate increased to 11% (threshold: 10%)', time: '45m ago', employee: 'Dana' },
  ];

  const totalCost = employees.reduce((a, e) => a + e.costToday, 0);
  const avgCompletion = Math.round(employees.reduce((a, e) => a + e.completionRate, 0) / employees.length);

  return (
    <div>
      <PageHeader title="Observability & Monitoring" subtitle="Real-time metrics, charts, and anomaly detection" />

      {/* Gauges */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
          <h3 className="text-white font-semibold text-sm mb-2">Cost vs Budget</h3>
          <div className="flex items-center gap-6">
            <div className="relative" style={{ width: 120, height: 120 }}>
              <ResponsiveContainer width={120} height={120}>
                <RadialBarChart
                  innerRadius={35}
                  outerRadius={55}
                  data={costGaugeData}
                  startAngle={90}
                  endAngle={-270}
                >
                  <RadialBar dataKey="value" cornerRadius={4} background={{ fill: '#1e293b' }} />
                </RadialBarChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-blue-400 font-bold text-sm">${totalCost.toFixed(1)}</div>
                  <div className="text-slate-400 text-xs">/ $50</div>
                </div>
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold text-white">{((totalCost / 50) * 100).toFixed(1)}%</div>
              <div className="text-slate-400 text-sm">of daily budget used</div>
              <div className="text-green-400 text-xs mt-1">On track</div>
            </div>
          </div>
        </div>

        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
          <h3 className="text-white font-semibold text-sm mb-2">Task Completion Rate</h3>
          <div className="flex items-center gap-6">
            <div className="relative" style={{ width: 120, height: 120 }}>
              <ResponsiveContainer width={120} height={120}>
                <RadialBarChart
                  innerRadius={35}
                  outerRadius={55}
                  data={completionGaugeData}
                  startAngle={90}
                  endAngle={-270}
                >
                  <RadialBar dataKey="value" cornerRadius={4} background={{ fill: '#1e293b' }} />
                </RadialBarChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-green-400 font-bold text-base">{avgCompletion}%</div>
                </div>
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold text-white">{avgCompletion}%</div>
              <div className="text-slate-400 text-sm">avg completion rate</div>
              <div className="text-green-400 text-xs mt-1">↑ 4% vs yesterday</div>
            </div>
          </div>
        </div>
      </div>

      {/* Line charts */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
          <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-blue-400" /> Messages Over Time
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={msgData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="time" tick={{ fill: '#64748b', fontSize: 10 }} interval={5} />
              <YAxis tick={{ fill: '#64748b', fontSize: 10 }} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }} />
              <Line type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={2} dot={false} name="Messages" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
          <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-purple-400" /> Token Usage
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={tokenData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="time" tick={{ fill: '#64748b', fontSize: 10 }} interval={5} />
              <YAxis tick={{ fill: '#64748b', fontSize: 10 }} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }} />
              <Line type="monotone" dataKey="value" stroke="#a855f7" strokeWidth={2} dot={false} name="Tokens" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
          <h3 className="text-white font-semibold text-sm mb-4">Tasks by Employee</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={tasksByEmployee}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 11 }} />
              <YAxis tick={{ fill: '#64748b', fontSize: 10 }} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }} />
              <Bar dataKey="tasks" name="Tasks" radius={[4, 4, 0, 0]}>
                {tasksByEmployee.map((entry, idx) => (
                  <rect key={idx} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
          <h3 className="text-white font-semibold text-sm mb-4">Response Latency (ms)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={latencyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="time" tick={{ fill: '#64748b', fontSize: 10 }} interval={5} />
              <YAxis tick={{ fill: '#64748b', fontSize: 10 }} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }} />
              <Line type="monotone" dataKey="value" stroke="#f59e0b" strokeWidth={2} dot={false} name="Latency (ms)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Anomaly alerts */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
          <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-yellow-400" /> Anomaly Detection Alerts
          </h3>
          <div className="space-y-2">
            {alerts.map(alert => (
              <div key={alert.id} className={`flex items-start gap-3 p-3 rounded-lg border ${
                alert.severity === 'high' ? 'border-red-500/30 bg-red-500/5' :
                alert.severity === 'medium' ? 'border-yellow-500/30 bg-yellow-500/5' :
                'border-slate-600/30 bg-slate-700/20'
              }`}>
                <AlertTriangle className={`w-4 h-4 flex-shrink-0 mt-0.5 ${
                  alert.severity === 'high' ? 'text-red-400' :
                  alert.severity === 'medium' ? 'text-yellow-400' : 'text-slate-400'
                }`} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-200">{alert.message}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-slate-500">{alert.time}</span>
                    <span className={`text-xs font-medium ${
                      alert.employee === 'Alex' ? 'text-blue-400' :
                      alert.employee === 'Morgan' ? 'text-purple-400' :
                      alert.employee === 'Casey' ? 'text-orange-400' : 'text-green-400'
                    }`}>{alert.employee}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* KPI Table */}
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
          <h3 className="text-white font-semibold text-sm mb-4">Digital Employee KPIs</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-slate-400 uppercase tracking-wider">
                  <th className="text-left pb-2 pr-3">Agent</th>
                  <th className="text-right pb-2 pr-3">Convos</th>
                  <th className="text-right pb-2 pr-3">Complete</th>
                  <th className="text-right pb-2 pr-3">Escalate</th>
                  <th className="text-right pb-2">Cost</th>
                </tr>
              </thead>
              <tbody>
                {employees.map(emp => (
                  <tr key={emp.id} className="border-t border-slate-700/30">
                    <td className="py-2 pr-3">
                      <div className="flex items-center gap-2">
                        <span>{emp.emoji}</span>
                        <span className={`font-medium ${emp.colorClass}`}>{emp.name}</span>
                      </div>
                    </td>
                    <td className="py-2 pr-3 text-right text-slate-300">{emp.conversationsToday}</td>
                    <td className="py-2 pr-3 text-right">
                      <span className={emp.completionRate >= 90 ? 'text-green-400' : 'text-yellow-400'}>{emp.completionRate}%</span>
                    </td>
                    <td className="py-2 pr-3 text-right">
                      <span className={emp.escalationRate <= 5 ? 'text-green-400' : emp.escalationRate <= 10 ? 'text-yellow-400' : 'text-red-400'}>{emp.escalationRate}%</span>
                    </td>
                    <td className="py-2 text-right text-slate-300">${emp.costToday.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Tool usage bar chart */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <h3 className="text-white font-semibold text-sm mb-4">Tool Usage Distribution</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={toolUsage} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis type="number" tick={{ fill: '#64748b', fontSize: 10 }} />
            <YAxis type="category" dataKey="name" tick={{ fill: '#94a3b8', fontSize: 11 }} width={80} />
            <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }} />
            <Bar dataKey="count" name="Calls" radius={[0, 4, 4, 0]} fill="#3b82f6" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
