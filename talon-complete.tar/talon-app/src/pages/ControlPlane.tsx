import { useState } from 'react';
import { Settings, Power, Pause, Play, EyeOff, Eye, X, CheckCircle, XCircle, Shield, Calendar } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader, RiskBadge, StatusBadge } from '../components/UI';
import { OPA_POLICIES } from '../data/mockData';

function KillSwitchModal({ onConfirm, onCancel }: { onConfirm: () => void; onCancel: () => void }) {
  const [typed, setTyped] = useState('');
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onCancel}>
      <div className="bg-slate-900 border border-red-500/50 rounded-xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-red-500/20 border border-red-500/40 flex items-center justify-center">
            <Power className="w-5 h-5 text-red-400" />
          </div>
          <div>
            <h3 className="text-white font-bold">Global Kill Switch</h3>
            <p className="text-red-400 text-sm">This will pause ALL digital employees immediately</p>
          </div>
        </div>
        <p className="text-slate-300 text-sm mb-4">
          All active ReAct loops will be suspended. State will be checkpointed for recovery. Type <span className="font-mono text-red-400">KILL ALL AGENTS</span> to confirm.
        </p>
        <input
          type="text"
          value={typed}
          onChange={e => setTyped(e.target.value)}
          placeholder="Type KILL ALL AGENTS"
          className="w-full bg-slate-800 border border-slate-600 text-slate-200 rounded-lg px-3 py-2 text-sm mb-4 outline-none focus:border-red-500"
        />
        <div className="flex gap-3">
          <button
            onClick={onConfirm}
            disabled={typed !== 'KILL ALL AGENTS'}
            className="flex-1 py-2 rounded-lg bg-red-600 text-white font-semibold text-sm hover:bg-red-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            Execute Kill Switch
          </button>
          <button onClick={onCancel} className="flex-1 py-2 rounded-lg bg-slate-700 text-slate-300 text-sm hover:bg-slate-600">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

export default function ControlPlane() {
  const { employees, hitlRequests, approveHitl, rejectHitl, pauseEmployee, resumeEmployee, killEmployee, globalKillSwitch } = useApp();
  const [showKillModal, setShowKillModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'controls' | 'hitl' | 'policy' | 'schedule'>('controls');

  const pendingHitl = hitlRequests.filter(r => r.status === 'pending');

  return (
    <div>
      <PageHeader title="Control Plane" subtitle="Global controls, HITL queue, policy configuration, and scheduling" />

      {/* Global kill switch */}
      <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Power className="w-5 h-5 text-red-400" />
          <div>
            <div className="text-white font-semibold">Global Kill Switch</div>
            <div className="text-slate-400 text-sm">Immediately pause all active digital employees</div>
          </div>
        </div>
        <button
          onClick={() => setShowKillModal(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-600 text-white font-semibold text-sm hover:bg-red-700 transition-colors"
        >
          <Power className="w-4 h-4" /> Kill All Agents
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-slate-700/50">
        {(['controls', 'hitl', 'policy', 'schedule'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors -mb-px ${
              activeTab === tab
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab === 'hitl' ? `HITL Queue ${pendingHitl.length > 0 ? `(${pendingHitl.length})` : ''}` :
             tab === 'controls' ? 'Agent Controls' :
             tab === 'policy' ? 'OPA Policy' : 'Schedule'}
          </button>
        ))}
      </div>

      {/* Agent Controls */}
      {activeTab === 'controls' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {employees.map(emp => (
            <div key={emp.id} className={`bg-slate-800/50 border ${emp.borderClass} rounded-xl p-4`}>
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl ${emp.bgClass} flex items-center justify-center text-xl border ${emp.borderClass}`}>
                  {emp.emoji}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-white">{emp.name}</div>
                  <div className={`text-xs ${emp.colorClass}`}>{emp.role}</div>
                </div>
                <StatusBadge status={emp.status} />
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => emp.status === 'active' ? pauseEmployee(emp.id) : resumeEmployee(emp.id)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-700/50 text-slate-300 text-xs border border-slate-600/30 hover:bg-slate-700 transition-colors"
                >
                  {emp.status === 'active' ? <><Pause className="w-3.5 h-3.5" /> Pause</> : <><Play className="w-3.5 h-3.5" /> Resume</>}
                </button>
                <button className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-yellow-500/10 text-yellow-400 text-xs border border-yellow-500/20 hover:bg-yellow-500/20 transition-colors">
                  <EyeOff className="w-3.5 h-3.5" /> Read-Only
                </button>
                <button className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-purple-500/10 text-purple-400 text-xs border border-purple-500/20 hover:bg-purple-500/20 transition-colors">
                  <Eye className="w-3.5 h-3.5" /> Supervised
                </button>
                <button
                  onClick={() => killEmployee(emp.id)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-red-500/10 text-red-400 text-xs border border-red-500/20 hover:bg-red-500/20 transition-colors"
                >
                  <X className="w-3.5 h-3.5" /> Kill
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* HITL Queue */}
      {activeTab === 'hitl' && (
        <div className="space-y-4">
          {hitlRequests.length === 0 && (
            <div className="text-center py-12 text-slate-400">
              <CheckCircle className="w-12 h-12 mx-auto mb-3 text-green-400/30" />
              <p>No pending HITL requests</p>
            </div>
          )}
          {hitlRequests.map(req => (
            <div key={req.id} className={`bg-slate-800/50 border rounded-xl p-4 ${
              req.status === 'pending' ? 'border-yellow-500/30' :
              req.status === 'approved' ? 'border-green-500/30' : 'border-red-500/30'
            }`}>
              <div className="flex items-start justify-between gap-4 mb-3">
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-lg flex-shrink-0 ${
                    req.employeeId === 'alex' ? 'bg-blue-500/20' :
                    req.employeeId === 'dana' ? 'bg-green-500/20' :
                    req.employeeId === 'morgan' ? 'bg-purple-500/20' :
                    req.employeeId === 'casey' ? 'bg-orange-500/20' : 'bg-yellow-500/20'
                  }`}>
                    {req.employeeId === 'alex' ? '🛡️' : req.employeeId === 'dana' ? '💚' : req.employeeId === 'morgan' ? '🔮' : req.employeeId === 'casey' ? '🔒' : '📋'}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-sm font-medium ${
                        req.employeeId === 'alex' ? 'text-blue-400' :
                        req.employeeId === 'dana' ? 'text-green-400' :
                        req.employeeId === 'morgan' ? 'text-purple-400' :
                        req.employeeId === 'casey' ? 'text-orange-400' : 'text-yellow-400'
                      }`}>{req.employeeName}</span>
                      <RiskBadge level={req.riskLevel} />
                    </div>
                    <p className="text-white font-medium text-sm">{req.task}</p>
                    <p className="text-slate-400 text-xs mt-1">{req.reason}</p>
                    <p className="text-slate-500 text-xs mt-1">{req.timestamp.toLocaleString()}</p>
                  </div>
                </div>
                {req.status === 'pending' ? (
                  <div className="flex gap-2 flex-shrink-0">
                    <button
                      onClick={() => approveHitl(req.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-600 text-white text-sm font-medium hover:bg-green-700"
                    >
                      <CheckCircle className="w-4 h-4" /> Approve
                    </button>
                    <button
                      onClick={() => rejectHitl(req.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 text-white text-sm font-medium hover:bg-red-700"
                    >
                      <XCircle className="w-4 h-4" /> Reject
                    </button>
                  </div>
                ) : (
                  <span className={`px-3 py-1.5 rounded-lg text-sm font-medium ${
                    req.status === 'approved' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                  }`}>
                    {req.status === 'approved' ? '✓ Approved' : '✗ Rejected'}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* OPA Policy */}
      {activeTab === 'policy' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3 bg-blue-500/10 border border-blue-500/20 rounded-xl p-3">
            <Shield className="w-4 h-4 text-blue-400" />
            <span className="text-blue-300 text-sm">Open Policy Agent (OPA) — Rego policy language. All agent actions are evaluated against these rules before execution.</span>
          </div>
          <div className="bg-slate-900/80 border border-slate-700/50 rounded-xl p-4 overflow-x-auto">
            <pre className="text-sm text-green-300 font-mono leading-relaxed whitespace-pre-wrap">{OPA_POLICIES}</pre>
          </div>
        </div>
      )}

      {/* Schedule */}
      {activeTab === 'schedule' && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-4 h-4 text-blue-400" />
            <h3 className="text-white font-semibold">Proactive Task Schedule</h3>
          </div>
          {[
            { emp: 'Alex', emoji: '🛡️', color: 'text-blue-400', tasks: [
              { cron: '*/5 * * * *', desc: 'Check Kubernetes cluster health', next: '2m' },
              { cron: '0 * * * *', desc: 'Pull PagerDuty incident digest', next: '47m' },
              { cron: '0 9 * * 1', desc: 'Generate weekly SRE report', next: 'Mon 09:00' },
            ]},
            { emp: 'Dana', emoji: '💚', color: 'text-green-400', tasks: [
              { cron: '*/10 * * * *', desc: 'Check ServiceNow ticket queue', next: '8m' },
              { cron: '0 8 * * *', desc: 'Send daily helpdesk summary', next: '3h' },
            ]},
            { emp: 'Morgan', emoji: '🔮', color: 'text-purple-400', tasks: [
              { cron: '0 7 * * 1-5', desc: 'Run daily revenue forecast', next: 'Tomorrow 07:00' },
              { cron: '0 17 * * 5', desc: 'Generate weekly data quality report', next: 'Fri 17:00' },
            ]},
            { emp: 'Casey', emoji: '🔒', color: 'text-orange-400', tasks: [
              { cron: '*/2 * * * *', desc: 'Poll Splunk SIEM for threats', next: '1m' },
              { cron: '0 0 * * *', desc: 'Run daily vulnerability scan', next: 'Midnight' },
            ]},
            { emp: 'Jordan', emoji: '📋', color: 'text-yellow-400', tasks: [
              { cron: '0 9 * * 1', desc: 'Send sprint kickoff summary', next: 'Mon 09:00' },
              { cron: '0 17 * * 5', desc: 'Generate sprint retrospective draft', next: 'Fri 17:00' },
            ]},
          ].map(item => (
            <div key={item.emp} className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <span>{item.emoji}</span>
                <span className={`font-semibold text-sm ${item.color}`}>{item.emp}</span>
              </div>
              <div className="space-y-2">
                {item.tasks.map((task, i) => (
                  <div key={i} className="flex items-center gap-3 p-2 bg-slate-700/30 rounded-lg">
                    <code className="text-xs text-slate-400 font-mono bg-slate-800/50 px-2 py-1 rounded">{task.cron}</code>
                    <span className="text-sm text-slate-300 flex-1">{task.desc}</span>
                    <span className="text-xs text-slate-500">Next: {task.next}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {showKillModal && (
        <KillSwitchModal
          onConfirm={() => { globalKillSwitch(); setShowKillModal(false); }}
          onCancel={() => setShowKillModal(false)}
        />
      )}
    </div>
  );
}
