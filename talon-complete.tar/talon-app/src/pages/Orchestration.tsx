import { Network, ArrowRight, Users, GitBranch, Share2, Layers } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader } from '../components/UI';
import { generateDelegationLinks } from '../data/mockData';

const DELEGATION_LINKS = generateDelegationLinks();

const PATTERNS = [
  {
    name: 'Delegation',
    icon: '→',
    desc: 'Alex delegates a sub-task to Morgan: "Pull Snowflake error rates for the last hour"',
    color: 'blue',
    steps: ['Alex receives alert', 'Alex creates sub-task', 'Delegates to Morgan', 'Morgan returns results', 'Alex incorporates data'],
  },
  {
    name: 'Supervisor-Worker',
    icon: '⊤',
    desc: 'Jordan coordinates with Dana and Morgan in parallel to compile sprint metrics',
    color: 'green',
    steps: ['Jordan defines goal', 'Dispatches to Dana + Morgan', 'Both work in parallel', 'Jordan aggregates results', 'Jordan delivers report'],
  },
  {
    name: 'Escalation Chain',
    icon: '↑',
    desc: 'Casey detects a critical security event and escalates through the chain',
    color: 'red',
    steps: ['Casey detects threat', 'Classifies as P0', 'Escalates to human SOC', 'Human reviews', 'Remediation plan'],
  },
  {
    name: 'Parallel Consultation',
    icon: '⊗',
    desc: 'Alex consults both Casey (security) and Morgan (data) simultaneously before making a decision',
    color: 'purple',
    steps: ['Alex identifies question', 'Asks Casey (security)', 'Asks Morgan (data)', 'Waits for both', 'Makes informed decision'],
  },
];

function NodeGraph() {
  const { employees } = useApp();

  const positions = [
    { x: 200, y: 150 }, // Alex
    { x: 450, y: 80 },  // Dana
    { x: 500, y: 250 }, // Morgan
    { x: 100, y: 280 }, // Casey
    { x: 320, y: 310 }, // Jordan
  ];

  return (
    <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-4 overflow-x-auto">
      <svg viewBox="0 0 600 400" className="w-full" style={{ minHeight: 300 }}>
        {/* Delegation edges */}
        {DELEGATION_LINKS.map((link, i) => {
          const fromIdx = employees.findIndex(e => e.id === link.from);
          const toIdx = employees.findIndex(e => e.id === link.to);
          if (fromIdx < 0 || toIdx < 0) return null;
          const from = positions[fromIdx];
          const to = positions[toIdx];
          const isActive = link.status === 'active';
          return (
            <g key={i}>
              <line
                x1={from.x} y1={from.y}
                x2={to.x} y2={to.y}
                stroke={isActive ? '#3b82f6' : '#475569'}
                strokeWidth={isActive ? 2 : 1}
                strokeDasharray={isActive ? '0' : '4 4'}
                opacity={isActive ? 0.8 : 0.4}
              />
              {isActive && (
                <circle r={4} fill="#3b82f6" opacity={0.9}>
                  <animateMotion
                    dur="2s"
                    repeatCount="indefinite"
                    path={`M${from.x},${from.y} L${to.x},${to.y}`}
                  />
                </circle>
              )}
            </g>
          );
        })}

        {/* Employee nodes */}
        {employees.map((emp, idx) => {
          const pos = positions[idx];
          return (
            <g key={emp.id}>
              <circle
                cx={pos.x} cy={pos.y} r={32}
                fill={`${emp.color}20`}
                stroke={emp.color}
                strokeWidth={2}
              />
              {emp.status === 'active' && (
                <circle
                  cx={pos.x} cy={pos.y} r={36}
                  fill="none"
                  stroke={emp.color}
                  strokeWidth={1}
                  opacity={0.3}
                >
                  <animate attributeName="r" values="32;40;32" dur="2s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.3;0;0.3" dur="2s" repeatCount="indefinite" />
                </circle>
              )}
              <text x={pos.x} y={pos.y - 2} textAnchor="middle" dominantBaseline="middle" fontSize={22}>
                {emp.emoji}
              </text>
              <text x={pos.x} y={pos.y + 44} textAnchor="middle" fill="#e2e8f0" fontSize={11} fontWeight="600">
                {emp.name}
              </text>
              <text x={pos.x} y={pos.y + 57} textAnchor="middle" fill={emp.color} fontSize={9}>
                {emp.role.split(' ')[0]}
              </text>
              {/* Status dot */}
              <circle
                cx={pos.x + 22} cy={pos.y - 22} r={5}
                fill={emp.status === 'active' ? '#22c55e' : emp.status === 'idle' ? '#eab308' : '#94a3b8'}
              />
            </g>
          );
        })}
      </svg>
    </div>
  );
}

export default function Orchestration() {
  const { employees } = useApp();

  return (
    <div>
      <PageHeader title="Multi-Agent Orchestration" subtitle="Delegation relationships, collaboration patterns, and active tasks" />

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
        {/* Node graph */}
        <div className="xl:col-span-2">
          <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
            <Network className="w-4 h-4 text-blue-400" /> Agent Relationship Graph
          </h3>
          <NodeGraph />
        </div>

        {/* Active delegations */}
        <div>
          <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
            <ArrowRight className="w-4 h-4 text-green-400" /> Active Delegations
          </h3>
          <div className="space-y-3">
            {DELEGATION_LINKS.map((link, i) => {
              const fromEmp = employees.find(e => e.id === link.from);
              const toEmp = employees.find(e => e.id === link.to);
              if (!fromEmp || !toEmp) return null;
              return (
                <div key={i} className={`bg-slate-800/50 border rounded-xl p-3 ${
                  link.status === 'active' ? 'border-blue-500/30' :
                  link.status === 'completed' ? 'border-green-500/30' : 'border-slate-600/30'
                }`}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className={fromEmp.colorClass}>{fromEmp.name}</span>
                    <ArrowRight className="w-3 h-3 text-slate-400" />
                    <span className={toEmp.colorClass}>{toEmp.name}</span>
                    <span className={`ml-auto text-xs px-2 py-0.5 rounded-full ${
                      link.status === 'active' ? 'bg-blue-500/20 text-blue-400' :
                      link.status === 'completed' ? 'bg-green-500/20 text-green-400' : 'bg-slate-500/20 text-slate-400'
                    }`}>{link.status}</span>
                  </div>
                  <p className="text-xs text-slate-400">{link.task}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Collaboration patterns */}
      <div>
        <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
          <GitBranch className="w-4 h-4 text-purple-400" /> Collaboration Patterns
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {PATTERNS.map(pattern => (
            <div key={pattern.name} className={`bg-slate-800/50 border border-${pattern.color}-500/20 rounded-xl p-4`}>
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-8 h-8 rounded-lg bg-${pattern.color}-500/20 flex items-center justify-center text-lg`}>
                  {pattern.icon}
                </div>
                <div>
                  <h4 className="text-white font-semibold text-sm">{pattern.name}</h4>
                </div>
              </div>
              <p className="text-slate-400 text-xs mb-3">{pattern.desc}</p>
              <div className="flex items-center gap-1 flex-wrap">
                {pattern.steps.map((step, idx) => (
                  <div key={idx} className="flex items-center gap-1">
                    <div className={`px-2 py-1 rounded text-xs bg-${pattern.color}-500/10 text-${pattern.color}-300 border border-${pattern.color}-500/20`}>
                      {step}
                    </div>
                    {idx < pattern.steps.length - 1 && <ArrowRight className="w-3 h-3 text-slate-600 flex-shrink-0" />}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Agent capabilities matrix */}
      <div className="mt-6 bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-400" /> Agent Capability Matrix
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-slate-400 uppercase tracking-wider">
                <th className="text-left pb-2 pr-4">Agent</th>
                {['Infra Ops', 'Security', 'Data Analysis', 'Communication', 'Project Mgmt', 'Code Execution'].map(cap => (
                  <th key={cap} className="text-center pb-2 px-2">{cap}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { emp: employees.find(e => e.id === 'alex'), caps: [true, true, false, true, false, true] },
                { emp: employees.find(e => e.id === 'dana'), caps: [false, false, false, true, true, false] },
                { emp: employees.find(e => e.id === 'morgan'), caps: [false, false, true, false, false, true] },
                { emp: employees.find(e => e.id === 'casey'), caps: [false, true, true, false, false, false] },
                { emp: employees.find(e => e.id === 'jordan'), caps: [false, false, false, true, true, false] },
              ].map(row => row.emp && (
                <tr key={row.emp.id} className="border-t border-slate-700/30">
                  <td className="py-2.5 pr-4">
                    <div className="flex items-center gap-2">
                      <span>{row.emp.emoji}</span>
                      <span className={`font-medium ${row.emp.colorClass}`}>{row.emp.name}</span>
                    </div>
                  </td>
                  {row.caps.map((has, i) => (
                    <td key={i} className="py-2.5 px-2 text-center">
                      {has ? <span className="text-green-400">✓</span> : <span className="text-slate-700">–</span>}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
