import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { DigitalEmployee, ActivityEvent, AuditEvent, HitlRequest } from '../types';
import { EMPLOYEES, generateActivityFeed, generateAuditEvents, generateHitlRequests } from '../data/mockData';

interface AppState {
  employees: DigitalEmployee[];
  activityFeed: ActivityEvent[];
  auditEvents: AuditEvent[];
  hitlRequests: HitlRequest[];
  globalMetrics: {
    totalMessages: number;
    tasksCompleted: number;
    tasksChange: number;
    avgResponseTime: number;
    proactiveFired: number;
    totalCost: number;
  };
  systemHealth: {
    api: number;
    memory: number;
    tools: number;
    latency: number;
  };
  selectedEmployeeId: string | null;
}

interface AppContextType extends AppState {
  selectEmployee: (id: string | null) => void;
  pauseEmployee: (id: string) => void;
  resumeEmployee: (id: string) => void;
  killEmployee: (id: string) => void;
  approveHitl: (id: string) => void;
  rejectHitl: (id: string) => void;
  globalKillSwitch: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

const REACT_STATES: DigitalEmployee['reactState'][] = ['perceive', 'plan', 'act', 'observe', 'decide'];

export function AppProvider({ children }: { children: ReactNode }) {
  const [employees, setEmployees] = useState<DigitalEmployee[]>(EMPLOYEES);
  const [activityFeed, setActivityFeed] = useState<ActivityEvent[]>(generateActivityFeed(25));
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>(generateAuditEvents(50));
  const [hitlRequests, setHitlRequests] = useState<HitlRequest[]>(generateHitlRequests());
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [globalMetrics, setGlobalMetrics] = useState({
    totalMessages: 2847,
    tasksCompleted: 163,
    tasksChange: 12,
    avgResponseTime: 1.46,
    proactiveFired: 47,
    totalCost: 16.03,
  });
  const [systemHealth] = useState({
    api: 99.8,
    memory: 87.3,
    tools: 94.2,
    latency: 142,
  });

  // Animate ReAct states
  useEffect(() => {
    const interval = setInterval(() => {
      setEmployees(prev => prev.map(emp => {
        if (emp.status !== 'active') return emp;
        const idx = REACT_STATES.indexOf(emp.reactState);
        return { ...emp, reactState: REACT_STATES[(idx + 1) % REACT_STATES.length] };
      }));
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  // Add new activity events
  useEffect(() => {
    const interval = setInterval(() => {
      const newEvents = generateActivityFeed(1);
      setActivityFeed(prev => [...newEvents, ...prev].slice(0, 100));
      // Sometimes add audit event too
      if (Math.random() > 0.5) {
        const newAudit = generateAuditEvents(1);
        setAuditEvents(prev => [...newAudit, ...prev].slice(0, 200));
      }
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Update metrics
  useEffect(() => {
    const interval = setInterval(() => {
      setGlobalMetrics(prev => ({
        ...prev,
        totalMessages: prev.totalMessages + Math.floor(Math.random() * 3),
        tasksCompleted: prev.tasksCompleted + (Math.random() > 0.7 ? 1 : 0),
        proactiveFired: prev.proactiveFired + (Math.random() > 0.8 ? 1 : 0),
        totalCost: prev.totalCost + Math.random() * 0.01,
        avgResponseTime: 1.2 + Math.random() * 0.8,
      }));
      setEmployees(prev => prev.map(emp => ({
        ...emp,
        conversationsToday: emp.conversationsToday + (Math.random() > 0.8 ? 1 : 0),
        tokensUsed: emp.tokensUsed + Math.floor(Math.random() * 500),
      })));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const selectEmployee = useCallback((id: string | null) => setSelectedEmployeeId(id), []);

  const pauseEmployee = useCallback((id: string) => {
    setEmployees(prev => prev.map(e => e.id === id ? { ...e, status: 'paused', currentTask: 'Paused by operator' } : e));
  }, []);

  const resumeEmployee = useCallback((id: string) => {
    setEmployees(prev => prev.map(e => e.id === id ? { ...e, status: 'active' } : e));
  }, []);

  const killEmployee = useCallback((id: string) => {
    setEmployees(prev => prev.map(e => e.id === id ? { ...e, status: 'error', currentTask: 'KILLED by operator' } : e));
  }, []);

  const approveHitl = useCallback((id: string) => {
    setHitlRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'approved' } : r));
  }, []);

  const rejectHitl = useCallback((id: string) => {
    setHitlRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'rejected' } : r));
  }, []);

  const globalKillSwitch = useCallback(() => {
    setEmployees(prev => prev.map(e => ({ ...e, status: 'paused', currentTask: 'GLOBAL KILL SWITCH ACTIVATED' })));
  }, []);

  return (
    <AppContext.Provider value={{
      employees,
      activityFeed,
      auditEvents,
      hitlRequests,
      globalMetrics,
      systemHealth,
      selectedEmployeeId,
      selectEmployee,
      pauseEmployee,
      resumeEmployee,
      killEmployee,
      approveHitl,
      rejectHitl,
      globalKillSwitch,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
