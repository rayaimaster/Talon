export type EmployeeStatus = 'active' | 'idle' | 'paused' | 'error';
export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';
export type ToolStatus = 'available' | 'in-use' | 'rate-limited' | 'error';

export interface DigitalEmployee {
  id: string;
  name: string;
  role: string;
  emoji: string;
  color: string;
  colorClass: string;
  bgClass: string;
  borderClass: string;
  status: EmployeeStatus;
  currentTask: string;
  capabilities: string[];
  tools: string[];
  channels: string[];
  conversationsToday: number;
  completionRate: number;
  escalationRate: number;
  avgResponseTime: number;
  tokensUsed: number;
  costToday: number;
  episodicMemories: number;
  entityRecords: number;
  kbHits: number;
  reactState: ReactState;
}

export type ReactState = 'perceive' | 'plan' | 'act' | 'observe' | 'decide';

export interface ActivityEvent {
  id: string;
  timestamp: Date;
  employeeId: string;
  employeeName: string;
  action: string;
  detail: string;
  type: 'tool' | 'message' | 'proactive' | 'escalation' | 'memory' | 'delegation';
}

export interface AuditEvent {
  id: string;
  timestamp: Date;
  employeeId: string;
  employeeName: string;
  eventType: string;
  action: string;
  riskLevel: RiskLevel;
  outcome: 'success' | 'failure' | 'pending' | 'rejected';
  hash: string;
  detail: string;
  toolName?: string;
}

export interface MetricPoint {
  time: string;
  value: number;
}

export interface HitlRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  task: string;
  reason: string;
  riskLevel: RiskLevel;
  timestamp: Date;
  status: 'pending' | 'approved' | 'rejected';
}

export interface DelegationLink {
  from: string;
  to: string;
  task: string;
  status: 'active' | 'completed' | 'pending';
}

export interface Tool {
  name: string;
  category: string;
  status: ToolStatus;
  usageCount: number;
  lastUsed?: Date;
}

export interface MemoryEntry {
  id: string;
  tier: number;
  content: string;
  timestamp: Date;
  relevance?: number;
  tags: string[];
}
