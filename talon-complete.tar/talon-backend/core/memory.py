"""
SQLite-backed memory service for Project Talon agents.

Tables:
  - conversations   : full message history per conversation
  - episodic_memory : summarized memories per agent
  - entity_memory   : structured facts about known entities
"""

import json
import logging
import time
from typing import Any, Optional

import aiosqlite

logger = logging.getLogger(__name__)

# Default DB path — overridden by settings at startup
_DB_PATH = "talon.db"


def set_db_path(path: str) -> None:
    global _DB_PATH
    # Strip the "sqlite:///" prefix if present
    _DB_PATH = path.replace("sqlite:///", "").replace("sqlite://", "")


async def init_db() -> None:
    """Create tables if they don't exist."""
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT NOT NULL,
                agent_id    TEXT NOT NULL,
                role        TEXT NOT NULL,   -- 'user' | 'assistant' | 'tool'
                content     TEXT NOT NULL,   -- JSON-encoded for multi-part content
                timestamp   REAL NOT NULL
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_conv_id
            ON conversations (conversation_id, timestamp)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS episodic_memory (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id    TEXT NOT NULL,
                summary     TEXT NOT NULL,
                tags        TEXT NOT NULL DEFAULT '[]',  -- JSON array
                timestamp   REAL NOT NULL
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_ep_agent
            ON episodic_memory (agent_id, timestamp)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS entity_memory (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id    TEXT NOT NULL,
                entity_name TEXT NOT NULL,
                entity_type TEXT NOT NULL DEFAULT 'fact',
                facts       TEXT NOT NULL DEFAULT '{}',  -- JSON object
                updated_at  REAL NOT NULL,
                UNIQUE(agent_id, entity_name)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp   REAL NOT NULL,
                agent_id    TEXT NOT NULL,
                event_type  TEXT NOT NULL,
                user_id     TEXT,
                conversation_id TEXT,
                details     TEXT NOT NULL DEFAULT '{}'   -- JSON
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_audit_ts
            ON audit_log (timestamp DESC)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS agent_status (
                agent_id    TEXT PRIMARY KEY,
                status      TEXT NOT NULL DEFAULT 'active',  -- active | paused
                updated_at  REAL NOT NULL
            )
        """)

        await db.commit()
    logger.info("Database initialised at %s", _DB_PATH)


# ─── Conversation history ─────────────────────────────────────────────────────

async def get_conversation_history(
    conversation_id: str,
    agent_id: str,
    limit: int = 50,
) -> list[dict]:
    """
    Return the last `limit` messages for a conversation as a list of
    Anthropic-compatible message dicts: [{"role": ..., "content": ...}, ...].
    """
    async with aiosqlite.connect(_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """
            SELECT role, content FROM conversations
            WHERE conversation_id = ? AND agent_id = ?
            ORDER BY timestamp ASC
            LIMIT ?
            """,
            (conversation_id, agent_id, limit),
        ) as cursor:
            rows = await cursor.fetchall()

    messages = []
    for row in rows:
        try:
            content = json.loads(row["content"])
        except (json.JSONDecodeError, TypeError):
            content = row["content"]
        messages.append({"role": row["role"], "content": content})
    return messages


async def append_message(
    conversation_id: str,
    agent_id: str,
    role: str,
    content: Any,
) -> None:
    """Persist a single message to the conversation history."""
    if not isinstance(content, str):
        content_str = json.dumps(content, ensure_ascii=False)
    else:
        content_str = content

    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO conversations (conversation_id, agent_id, role, content, timestamp)
            VALUES (?, ?, ?, ?, ?)
            """,
            (conversation_id, agent_id, role, content_str, time.time()),
        )
        await db.commit()


# ─── Episodic memory ──────────────────────────────────────────────────────────

async def store_episodic(agent_id: str, summary: str, tags: list[str] | None = None) -> None:
    tags = tags or []
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO episodic_memory (agent_id, summary, tags, timestamp)
            VALUES (?, ?, ?, ?)
            """,
            (agent_id, summary, json.dumps(tags), time.time()),
        )
        await db.commit()


async def search_episodic(agent_id: str, query: str, limit: int = 5) -> list[dict]:
    """Simple keyword search over episodic memories."""
    async with aiosqlite.connect(_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        # SQLite FTS not guaranteed; use LIKE for portability
        async with db.execute(
            """
            SELECT summary, tags, timestamp FROM episodic_memory
            WHERE agent_id = ?
              AND (summary LIKE ? OR tags LIKE ?)
            ORDER BY timestamp DESC
            LIMIT ?
            """,
            (agent_id, f"%{query}%", f"%{query}%", limit),
        ) as cursor:
            rows = await cursor.fetchall()

    return [
        {
            "summary": row["summary"],
            "tags": json.loads(row["tags"]),
            "timestamp": row["timestamp"],
        }
        for row in rows
    ]


async def get_recent_episodic(agent_id: str, limit: int = 10) -> list[dict]:
    async with aiosqlite.connect(_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """
            SELECT summary, tags, timestamp FROM episodic_memory
            WHERE agent_id = ?
            ORDER BY timestamp DESC
            LIMIT ?
            """,
            (agent_id, limit),
        ) as cursor:
            rows = await cursor.fetchall()

    return [
        {
            "summary": row["summary"],
            "tags": json.loads(row["tags"]),
            "timestamp": row["timestamp"],
        }
        for row in rows
    ]


# ─── Entity memory ────────────────────────────────────────────────────────────

async def get_entity(agent_id: str, entity_name: str) -> Optional[dict]:
    async with aiosqlite.connect(_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """
            SELECT entity_name, entity_type, facts, updated_at
            FROM entity_memory
            WHERE agent_id = ? AND entity_name = ?
            """,
            (agent_id, entity_name),
        ) as cursor:
            row = await cursor.fetchone()

    if row is None:
        return None
    return {
        "entity_name": row["entity_name"],
        "entity_type": row["entity_type"],
        "facts": json.loads(row["facts"]),
        "updated_at": row["updated_at"],
    }


async def upsert_entity(
    agent_id: str,
    entity_name: str,
    entity_type: str,
    facts: dict,
) -> None:
    async with aiosqlite.connect(_DB_PATH) as db:
        # Merge with existing facts
        existing = await get_entity(agent_id, entity_name)
        merged_facts = {}
        if existing:
            merged_facts.update(existing["facts"])
        merged_facts.update(facts)

        await db.execute(
            """
            INSERT INTO entity_memory (agent_id, entity_name, entity_type, facts, updated_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(agent_id, entity_name) DO UPDATE SET
                entity_type = excluded.entity_type,
                facts       = excluded.facts,
                updated_at  = excluded.updated_at
            """,
            (agent_id, entity_name, entity_type, json.dumps(merged_facts), time.time()),
        )
        await db.commit()


async def search_entities(agent_id: str, query: str, limit: int = 5) -> list[dict]:
    async with aiosqlite.connect(_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """
            SELECT entity_name, entity_type, facts, updated_at
            FROM entity_memory
            WHERE agent_id = ?
              AND (entity_name LIKE ? OR facts LIKE ?)
            ORDER BY updated_at DESC
            LIMIT ?
            """,
            (agent_id, f"%{query}%", f"%{query}%", limit),
        ) as cursor:
            rows = await cursor.fetchall()

    return [
        {
            "entity_name": row["entity_name"],
            "entity_type": row["entity_type"],
            "facts": json.loads(row["facts"]),
            "updated_at": row["updated_at"],
        }
        for row in rows
    ]


# ─── Agent status ─────────────────────────────────────────────────────────────

async def get_agent_status(agent_id: str) -> str:
    async with aiosqlite.connect(_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT status FROM agent_status WHERE agent_id = ?",
            (agent_id,),
        ) as cursor:
            row = await cursor.fetchone()
    return row["status"] if row else "active"


async def set_agent_status(agent_id: str, status: str) -> None:
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO agent_status (agent_id, status, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(agent_id) DO UPDATE SET
                status     = excluded.status,
                updated_at = excluded.updated_at
            """,
            (agent_id, status, time.time()),
        )
        await db.commit()


# ─── Stats helpers ────────────────────────────────────────────────────────────

async def count_conversations(agent_id: Optional[str] = None) -> int:
    async with aiosqlite.connect(_DB_PATH) as db:
        if agent_id:
            async with db.execute(
                "SELECT COUNT(DISTINCT conversation_id) FROM conversations WHERE agent_id = ?",
                (agent_id,),
            ) as cursor:
                row = await cursor.fetchone()
        else:
            async with db.execute(
                "SELECT COUNT(DISTINCT conversation_id) FROM conversations"
            ) as cursor:
                row = await cursor.fetchone()
    return row[0] if row else 0


async def count_messages(agent_id: Optional[str] = None) -> int:
    async with aiosqlite.connect(_DB_PATH) as db:
        if agent_id:
            async with db.execute(
                "SELECT COUNT(*) FROM conversations WHERE agent_id = ?",
                (agent_id,),
            ) as cursor:
                row = await cursor.fetchone()
        else:
            async with db.execute("SELECT COUNT(*) FROM conversations") as cursor:
                row = await cursor.fetchone()
    return row[0] if row else 0


async def get_recent_conversations(agent_id: Optional[str] = None, limit: int = 20) -> list[dict]:
    async with aiosqlite.connect(_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        if agent_id:
            async with db.execute(
                """
                SELECT conversation_id, agent_id, role, content, timestamp
                FROM conversations
                WHERE agent_id = ?
                ORDER BY timestamp DESC
                LIMIT ?
                """,
                (agent_id, limit),
            ) as cursor:
                rows = await cursor.fetchall()
        else:
            async with db.execute(
                """
                SELECT conversation_id, agent_id, role, content, timestamp
                FROM conversations
                ORDER BY timestamp DESC
                LIMIT ?
                """,
                (limit,),
            ) as cursor:
                rows = await cursor.fetchall()

    return [
        {
            "conversation_id": row["conversation_id"],
            "agent_id": row["agent_id"],
            "role": row["role"],
            "content": row["content"],
            "timestamp": row["timestamp"],
        }
        for row in rows
    ]
