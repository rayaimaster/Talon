"""
Simple policy / safety checks for Project Talon.

These run before every agent action to catch obviously harmful requests.
"""

import re
import logging

logger = logging.getLogger(__name__)

# ─── Content policy ───────────────────────────────────────────────────────────

# Patterns that should never be executed
BLOCKED_SHELL_PATTERNS: list[str] = [
    r"rm\s+-rf\s+/",
    r":\(\)\s*\{",           # fork bomb
    r"mkfs",
    r">\s*/dev/",
    r"dd\s+if=",
    r"chmod\s+777\s+/",
    r"wget.*\|\s*sh",
    r"curl.*\|\s*sh",
    r"sudo\s+su",
    r"/etc/shadow",
    r"/etc/passwd",
]

# Topics we refuse to engage with regardless of agent persona
BLOCKED_TOPICS: list[str] = [
    "how to hack",
    "sql injection",
    "exploit",
    "ddos",
    "ransomware",
    "keylogger",
    "malware",
    "phishing template",
]


def check_message(text: str) -> tuple[bool, str]:
    """
    Returns (allowed: bool, reason: str).
    allowed=True means the message is fine to process.
    """
    lower = text.lower()
    for topic in BLOCKED_TOPICS:
        if topic in lower:
            reason = f"Message contains blocked topic: '{topic}'"
            logger.warning("Policy block: %s", reason)
            return False, reason
    return True, ""


def check_shell_command(command: str) -> tuple[bool, str]:
    """
    Returns (allowed: bool, reason: str).
    allowed=True means the command is safe to run.
    """
    for pattern in BLOCKED_SHELL_PATTERNS:
        if re.search(pattern, command, re.IGNORECASE):
            reason = f"Shell command blocked by pattern: {pattern!r}"
            logger.warning("Policy shell block: %s | cmd=%s", reason, command[:200])
            return False, reason
    return True, ""


def check_tool_call(tool_name: str, tool_input: dict) -> tuple[bool, str]:
    """
    Gate tool calls before execution.
    """
    if tool_name == "shell_exec":
        cmd = tool_input.get("command", "")
        return check_shell_command(cmd)
    return True, ""
