"""
Jira integration tool.

Operates in two modes, controlled by environment variables:
  - JIRA_BASE_URL set → real Jira Cloud REST API
  - Otherwise         → mock mode (returns realistic fake data)
"""

import logging
import os
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


def _is_mock() -> bool:
    return not os.environ.get("JIRA_BASE_URL", "").strip()


async def jira_get_issue(issue_key: str) -> str:
    """Fetch a Jira issue by key (e.g. 'ENG-123')."""
    if _is_mock():
        return _mock_issue(issue_key)

    base_url = os.environ["JIRA_BASE_URL"].rstrip("/")
    email = os.environ.get("JIRA_EMAIL", "")
    api_token = os.environ.get("JIRA_API_TOKEN", "")

    url = f"{base_url}/rest/api/3/issue/{issue_key}"
    auth = (email, api_token) if email and api_token else None

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(url, auth=auth)  # type: ignore[arg-type]
            resp.raise_for_status()
            data = resp.json()

        fields = data.get("fields", {})
        return (
            f"Issue: {data.get('key')}\n"
            f"Summary: {fields.get('summary', 'N/A')}\n"
            f"Status: {fields.get('status', {}).get('name', 'N/A')}\n"
            f"Priority: {fields.get('priority', {}).get('name', 'N/A')}\n"
            f"Assignee: {(fields.get('assignee') or {}).get('displayName', 'Unassigned')}\n"
            f"Reporter: {(fields.get('reporter') or {}).get('displayName', 'N/A')}\n"
            f"Description: {_extract_description(fields.get('description'))}\n"
        )
    except Exception as exc:
        logger.error("Jira get_issue failed: %s", exc)
        return f"❌ Failed to fetch Jira issue {issue_key}: {exc}"


async def jira_search(jql: str, max_results: int = 10) -> str:
    """Search Jira using JQL."""
    if _is_mock():
        return _mock_search(jql, max_results)

    base_url = os.environ["JIRA_BASE_URL"].rstrip("/")
    email = os.environ.get("JIRA_EMAIL", "")
    api_token = os.environ.get("JIRA_API_TOKEN", "")

    url = f"{base_url}/rest/api/3/search"
    auth = (email, api_token) if email and api_token else None

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                url,
                params={"jql": jql, "maxResults": max_results},
                auth=auth,  # type: ignore[arg-type]
            )
            resp.raise_for_status()
            data = resp.json()

        issues = data.get("issues", [])
        if not issues:
            return f"No issues found for JQL: {jql!r}"

        lines = [f"Found {len(issues)} issue(s) for: {jql!r}\n"]
        for issue in issues:
            fields = issue.get("fields", {})
            lines.append(
                f"  {issue.get('key')}: {fields.get('summary', 'N/A')} "
                f"[{fields.get('status', {}).get('name', '?')}]"
            )
        return "\n".join(lines)

    except Exception as exc:
        logger.error("Jira search failed: %s", exc)
        return f"❌ Jira search failed: {exc}"


async def jira_create_issue(
    project_key: str,
    summary: str,
    description: str = "",
    issue_type: str = "Task",
    priority: str = "Medium",
) -> str:
    """Create a new Jira issue."""
    if _is_mock():
        import random
        ticket_num = random.randint(100, 9999)
        fake_key = f"{project_key}-{ticket_num}"
        return (
            f"✅ [MOCK] Created Jira issue: {fake_key}\n"
            f"  Summary: {summary}\n"
            f"  Type: {issue_type} | Priority: {priority}\n"
            f"  URL: https://your-company.atlassian.net/browse/{fake_key}"
        )

    base_url = os.environ["JIRA_BASE_URL"].rstrip("/")
    email = os.environ.get("JIRA_EMAIL", "")
    api_token = os.environ.get("JIRA_API_TOKEN", "")

    payload = {
        "fields": {
            "project": {"key": project_key},
            "summary": summary,
            "description": {
                "type": "doc",
                "version": 1,
                "content": [
                    {
                        "type": "paragraph",
                        "content": [{"type": "text", "text": description}],
                    }
                ],
            },
            "issuetype": {"name": issue_type},
            "priority": {"name": priority},
        }
    }

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                f"{base_url}/rest/api/3/issue",
                json=payload,
                auth=(email, api_token),  # type: ignore[arg-type]
            )
            resp.raise_for_status()
            data = resp.json()

        key = data.get("key", "?")
        return (
            f"✅ Created Jira issue: {key}\n"
            f"  URL: {base_url}/browse/{key}"
        )
    except Exception as exc:
        logger.error("Jira create_issue failed: %s", exc)
        return f"❌ Failed to create Jira issue: {exc}"


# ── Mock helpers ──────────────────────────────────────────────────────────────

def _mock_issue(key: str) -> str:
    return (
        f"[MOCK] Issue: {key}\n"
        f"Summary: Example issue for {key}\n"
        f"Status: In Progress\n"
        f"Priority: Medium\n"
        f"Assignee: Jane Smith\n"
        f"Reporter: John Doe\n"
        f"Description: This is a mock Jira issue. Set JIRA_BASE_URL to use real Jira.\n"
    )


def _mock_search(jql: str, max_results: int) -> str:
    return (
        f"[MOCK] Jira search results for: {jql!r}\n\n"
        f"  ENG-101: Fix login timeout issue [In Progress]\n"
        f"  ENG-102: Update SSL certificates [Done]\n"
        f"  ENG-103: Kubernetes pod restart loop [Open]\n\n"
        f"(Set JIRA_BASE_URL environment variable to use real Jira)"
    )


def _extract_description(desc: Optional[dict]) -> str:
    """Extract plain text from Atlassian Document Format."""
    if not desc:
        return "N/A"
    if isinstance(desc, str):
        return desc[:500]
    # ADF format
    try:
        parts = []
        for block in desc.get("content", []):
            for inline in block.get("content", []):
                if inline.get("type") == "text":
                    parts.append(inline.get("text", ""))
        return " ".join(parts)[:500]
    except Exception:
        return str(desc)[:200]
