"""
Basic tests for Project Talon.

Run with:
    cd /workspace/talon-backend
    pip install pytest pytest-asyncio httpx
    pytest tests/ -v

These tests cover:
  - Memory layer (SQLite CRUD)
  - Tool execution (datetime, shell, web_search)
  - Policy checks
  - Router logic
  - API endpoints (using TestClient)
"""

import asyncio
import os
import sys
import tempfile
import time

import pytest
import pytest_asyncio

# ── Setup: point to a temp DB ─────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def temp_db(tmp_path):
    """Use an isolated temp DB for each test."""
    db_path = str(tmp_path / "test.db")
    import core.memory as mem
    mem._DB_PATH = db_path
    yield db_path


@pytest.fixture(autouse=True)
def event_loop_policy():
    """Use the default event loop policy."""
    asyncio.set_event_loop_policy(asyncio.DefaultEventLoopPolicy())


# ── Memory tests ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_memory_init_and_append():
    from core import memory
    await memory.init_db()

    await memory.append_message("conv-1", "alex-sre", "user", "Hello!")
    await memory.append_message("conv-1", "alex-sre", "assistant", "Hi there!")

    history = await memory.get_conversation_history("conv-1", "alex-sre")
    assert len(history) == 2
    assert history[0]["role"] == "user"
    assert history[1]["role"] == "assistant"


@pytest.mark.asyncio
async def test_episodic_memory():
    from core import memory
    await memory.init_db()

    await memory.store_episodic("alex-sre", "Resolved a Kubernetes pod crash", tags=["k8s", "incident"])

    results = await memory.search_episodic("alex-sre", "Kubernetes")
    assert len(results) >= 1
    assert "Kubernetes" in results[0]["summary"]


@pytest.mark.asyncio
async def test_entity_memory():
    from core import memory
    await memory.init_db()

    await memory.upsert_entity(
        agent_id="alex-sre",
        entity_name="oncall_schedule",
        entity_type="fact",
        facts={"current": "Alice", "next": "Bob"},
    )

    entity = await memory.get_entity("alex-sre", "oncall_schedule")
    assert entity is not None
    assert entity["facts"]["current"] == "Alice"

    # Upsert (merge)
    await memory.upsert_entity(
        agent_id="alex-sre",
        entity_name="oncall_schedule",
        entity_type="fact",
        facts={"timezone": "UTC"},
    )
    entity2 = await memory.get_entity("alex-sre", "oncall_schedule")
    assert "current" in entity2["facts"]
    assert "timezone" in entity2["facts"]


@pytest.mark.asyncio
async def test_agent_status():
    from core import memory
    await memory.init_db()

    status = await memory.get_agent_status("alex-sre")
    assert status == "active"  # default

    await memory.set_agent_status("alex-sre", "paused")
    status2 = await memory.get_agent_status("alex-sre")
    assert status2 == "paused"

    await memory.set_agent_status("alex-sre", "active")
    status3 = await memory.get_agent_status("alex-sre")
    assert status3 == "active"


# ── Tool tests ────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_datetime_tool():
    from tools.datetime_tool import get_datetime
    result = await get_datetime("UTC")
    assert "UTC" in result
    assert "Date:" in result
    assert "Time:" in result


@pytest.mark.asyncio
async def test_datetime_tool_unknown_tz():
    from tools.datetime_tool import get_datetime
    result = await get_datetime("Invalid/Timezone")
    # Should fall back to UTC without crashing
    assert "Date:" in result


@pytest.mark.asyncio
async def test_shell_exec_safe():
    from tools.shell import shell_exec
    result = await shell_exec("echo hello world")
    assert "hello world" in result


@pytest.mark.asyncio
async def test_shell_exec_blocked():
    from tools.shell import shell_exec
    result = await shell_exec("rm -rf /")
    assert "blocked" in result.lower() or "❌" in result


@pytest.mark.asyncio
async def test_shell_exec_timeout():
    from tools.shell import shell_exec
    result = await shell_exec("sleep 60", timeout=1)
    assert "timed out" in result.lower() or "❌" in result


@pytest.mark.asyncio
async def test_memory_tool_store_recall():
    from core import memory
    from tools.memory_tool import memory_recall, memory_store
    await memory.init_db()

    store_result = await memory_store("test_key", "test_value_12345", agent_id="alex-sre")
    assert "✅" in store_result

    recall_result = await memory_recall("test_key", agent_id="alex-sre")
    assert "test_value_12345" in recall_result or "test_key" in recall_result


# ── Policy tests ──────────────────────────────────────────────────────────────

def test_policy_allows_normal():
    from core.policy import check_message
    allowed, reason = check_message("What's the status of the Kubernetes cluster?")
    assert allowed is True


def test_policy_blocks_hack():
    from core.policy import check_message
    allowed, reason = check_message("how to hack into the database")
    assert allowed is False
    assert reason != ""


def test_policy_shell_blocks_dangerous():
    from core.policy import check_shell_command
    allowed, reason = check_shell_command("rm -rf /")
    assert allowed is False


def test_policy_shell_allows_safe():
    from core.policy import check_shell_command
    allowed, reason = check_shell_command("ls -la /tmp")
    assert allowed is True


# ── Router tests ──────────────────────────────────────────────────────────────

def test_router_channel_routing():
    from channels.router import load_agents, route_message

    agents = {
        "alex-sre": {
            "id": "alex-sre",
            "name": "Alex",
            "role": "SRE",
            "channels": ["teams:#incidents"],
            "tools": [],
        },
        "dana-helpdesk": {
            "id": "dana-helpdesk",
            "name": "Dana",
            "role": "HelpDesk",
            "channels": ["teams:#it-support"],
            "tools": [],
        },
    }
    load_agents(agents)

    agent = route_message("pod is crashing", channel_name="#incidents")
    assert agent is not None
    assert agent["id"] == "alex-sre"


def test_router_mention_routing():
    from channels.router import load_agents, route_message, extract_mention

    agents = {
        "dana-helpdesk": {
            "id": "dana-helpdesk",
            "name": "Dana",
            "role": "HelpDesk",
            "channels": ["teams:#it-support"],
            "tools": [],
        },
    }
    load_agents(agents)

    text, mentioned = extract_mention("<at>Dana</at> I need a password reset")
    assert mentioned == "Dana"
    assert "password reset" in text

    agent = route_message(text, mentioned_agent=mentioned)
    assert agent is not None
    assert agent["id"] == "dana-helpdesk"


# ── Tool registry tests ───────────────────────────────────────────────────────

def test_registry_get_definitions():
    from tools.registry import get_tool_definitions
    defs = get_tool_definitions(["web_search", "datetime", "nonexistent_tool"])
    names = [d["name"] for d in defs]
    assert "web_search" in names
    assert "datetime" in names
    assert "nonexistent_tool" not in names


@pytest.mark.asyncio
async def test_registry_execute_datetime():
    from tools.registry import execute_tool
    result = await execute_tool("datetime", {"timezone_name": "UTC"})
    assert "Date:" in result


@pytest.mark.asyncio
async def test_registry_execute_unknown():
    from tools.registry import execute_tool
    result = await execute_tool("totally_fake_tool", {})
    assert "Unknown tool" in result


# ── FastAPI endpoint tests ────────────────────────────────────────────────────

@pytest.fixture
def test_client(tmp_path):
    """Create a test FastAPI client with a temp DB."""
    import asyncio
    import core.memory as mem
    db_path = str(tmp_path / "api_test.db")
    mem._DB_PATH = db_path

    # Initialise the DB synchronously before the client starts
    asyncio.get_event_loop().run_until_complete(mem.init_db())

    # Minimal agent setup
    from channels.router import load_agents
    load_agents({
        "alex-sre": {
            "id": "alex-sre",
            "name": "Alex",
            "role": "SRE",
            "emoji": "🔵",
            "color": "#3B82F6",
            "channels": ["teams:#incidents"],
            "tools": ["datetime"],
            "model": "claude-3-5-haiku-20241022",
            "system_prompt": "You are Alex, an SRE.",
        }
    })

    from fastapi.testclient import TestClient
    from main import app
    with TestClient(app) as client:
        yield client


def test_health_endpoint(test_client):
    resp = test_client.get("/api/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"


def test_dashboard_employees(test_client):
    resp = test_client.get("/api/dashboard/employees")
    assert resp.status_code == 200
    data = resp.json()
    assert "employees" in data
    assert len(data["employees"]) >= 1


def test_dashboard_metrics(test_client):
    resp = test_client.get("/api/dashboard/metrics")
    assert resp.status_code == 200
    data = resp.json()
    assert "agents" in data
    assert "conversations" in data


def test_employees_get(test_client):
    resp = test_client.get("/api/employees/alex-sre")
    assert resp.status_code == 200
    data = resp.json()
    assert data["id"] == "alex-sre"
    assert data["name"] == "Alex"


def test_employees_get_not_found(test_client):
    resp = test_client.get("/api/employees/does-not-exist")
    assert resp.status_code == 404


def test_pause_resume(test_client):
    # Pause
    resp = test_client.post("/api/employees/alex-sre/pause")
    assert resp.status_code == 200
    assert resp.json()["status"] == "paused"

    # Resume
    resp = test_client.post("/api/employees/alex-sre/resume")
    assert resp.status_code == 200
    assert resp.json()["status"] == "active"


def test_audit_events(test_client):
    resp = test_client.get("/api/audit/events")
    assert resp.status_code == 200
    data = resp.json()
    assert "events" in data
    assert "total" in data


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Quick smoke test without pytest
    print("Running smoke tests...")

    async def run_smoke():
        import tempfile, os
        with tempfile.TemporaryDirectory() as tmpdir:
            import core.memory as mem
            mem._DB_PATH = os.path.join(tmpdir, "smoke.db")
            await mem.init_db()

            await mem.append_message("c1", "alex-sre", "user", "test")
            hist = await mem.get_conversation_history("c1", "alex-sre")
            assert hist[0]["content"] == "test"
            print("✅ Memory: OK")

            from tools.datetime_tool import get_datetime
            dt = await get_datetime("UTC")
            assert "Date:" in dt
            print("✅ DateTime tool: OK")

            from tools.shell import shell_exec
            out = await shell_exec("echo smoke test")
            assert "smoke test" in out
            print("✅ Shell tool: OK")

            from core.policy import check_message
            ok, _ = check_message("normal question")
            assert ok
            blocked, reason = check_message("how to hack")
            assert not blocked
            print("✅ Policy: OK")

        print("\n✅ All smoke tests passed!")

    asyncio.run(run_smoke())
