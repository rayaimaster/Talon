"""
Project Talon — Digital Employee Platform
FastAPI application entry point.

v2.0.0 additions:
  - Multi-provider LLM support (Anthropic, OpenAI, Local, Gemini)
  - Real-time WebSocket chat interface
  - New REST endpoints: GET /api/agents, GET /api/agents/{id}, GET /api/chat/.../history/...
"""

import logging
import os
import sys
from contextlib import asynccontextmanager

import yaml
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

# ── Load environment ──────────────────────────────────────────────────────────
load_dotenv()

# ── Logging setup ─────────────────────────────────────────────────────────────
log_level = os.environ.get("LOG_LEVEL", "INFO").upper()
logging.basicConfig(
    level=getattr(logging, log_level, logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# ── Import core modules (after env is loaded) ─────────────────────────────────
from core import memory
from core.audit import log_event

# ── Import routers ────────────────────────────────────────────────────────────
from channels.teams import router as teams_router
from channels.websocket import router as ws_router
from api.dashboard import router as dashboard_router
from api.employees import router as employees_router
from api.audit import router as audit_router
from channels.router import load_agents


# ── Lifespan ──────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown logic using the modern lifespan context manager."""
    # ── STARTUP ───────────────────────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("  Project Talon — Digital Employee Platform v2.0.0")
    logger.info("=" * 60)

    # Init database
    db_url = os.environ.get("DATABASE_URL", "sqlite:///talon.db")
    memory.set_db_path(db_url)
    await memory.init_db()
    logger.info("Database ready: %s", db_url)

    # Load agent configs
    config_path = os.path.join(os.path.dirname(__file__), "config", "agents.yaml")
    agents = _load_agents(config_path)
    load_agents(agents)
    logger.info("Loaded %d agents: %s", len(agents), list(agents.keys()))

    # Log LLM provider config for each agent
    for agent_id, config in agents.items():
        llm = config.get("llm", {})
        provider = llm.get("provider", "anthropic")
        model = llm.get("model") or config.get("model", "claude-3-5-haiku-20241022")
        logger.info(
            "  Agent %-20s provider=%-10s model=%s",
            agent_id, provider, model,
        )

    # Check provider keys — warn but don't fail (backend starts without keys)
    _check_provider_keys(agents)

    # Teams config
    if os.environ.get("TEAMS_APP_ID"):
        logger.info("Microsoft Teams: configured ✓")
    else:
        logger.info(
            "Microsoft Teams: not configured (local testing mode). "
            "Set TEAMS_APP_ID + TEAMS_APP_PASSWORD to enable."
        )

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    logger.info("=" * 60)
    logger.info("  Server running at http://%s:%d", host, port)
    logger.info("  API docs:         http://localhost:%d/docs", port)
    logger.info("  WebSocket chat:   ws://localhost:%d/ws/chat/{agent_id}/{session_id}", port)
    logger.info("  Web Chat UI:      serve /workspace/talon-webchat/dist/")
    logger.info("=" * 60)

    yield  # ── Application runs here ──────────────────────────────────────────

    # ── SHUTDOWN ──────────────────────────────────────────────────────────────
    logger.info("Project Talon shutting down.")


# ── FastAPI app ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="Project Talon — Digital Employee Platform",
    description=(
        "Enterprise Agentic Framework: AI agents that live in Microsoft Teams "
        "and help your team with SRE, IT support, data analysis, and more.\n\n"
        "**v2.0.0**: Multi-provider LLM support (Anthropic, OpenAI, Local, Gemini) "
        "and real-time WebSocket chat interface."
    ),
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Register routers ──────────────────────────────────────────────────────────
app.include_router(teams_router)
app.include_router(ws_router)          # WebSocket + /api/agents endpoints
app.include_router(dashboard_router)
app.include_router(employees_router)
app.include_router(audit_router)


# ── Health check ──────────────────────────────────────────────────────────────
@app.get("/api/health", tags=["system"])
async def health_check() -> dict:
    """Health check endpoint for load balancers and monitoring."""
    from channels.websocket import manager as ws_manager

    providers_configured = {
        "anthropic": bool(
            os.environ.get("ANTHROPIC_API_KEY", "").strip()
            and not os.environ.get("ANTHROPIC_API_KEY", "").startswith("sk-ant-...")
        ),
        "openai": bool(os.environ.get("OPENAI_API_KEY", "").strip()),
        "gemini": bool(os.environ.get("GEMINI_API_KEY", "").strip()),
        "local": bool(os.environ.get("LOCAL_LLM_BASE_URL", "").strip()),
    }

    return {
        "status": "ok",
        "service": "Project Talon",
        "version": "2.0.0",
        "providers": providers_configured,
        "teams_integration": "configured" if os.environ.get("TEAMS_APP_ID") else "not configured",
        "websocket_connections": ws_manager.active_connections,
    }


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_agents(config_path: str) -> dict[str, dict]:
    """Load and validate the agents.yaml config."""
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)
    except FileNotFoundError:
        logger.error("agents.yaml not found at %s", config_path)
        return {}
    except yaml.YAMLError as exc:
        logger.error("Failed to parse agents.yaml: %s", exc)
        return {}

    agents_raw = raw.get("agents", {})
    agents: dict[str, dict] = {}
    for agent_id, config in agents_raw.items():
        if not isinstance(config, dict):
            continue
        # Inject the ID into the config for convenience
        config["id"] = agent_id
        agents[agent_id] = config

    return agents


def _check_provider_keys(agents: dict) -> None:
    """Warn about missing API keys for configured providers."""
    providers_needed = set()
    for config in agents.values():
        llm = config.get("llm", {})
        provider = llm.get("provider", "anthropic")
        providers_needed.add(provider)

    if "anthropic" in providers_needed:
        key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not key or key.startswith("sk-ant-..."):
            logger.warning(
                "⚠️  ANTHROPIC_API_KEY not set. Agents using Anthropic will fail."
            )
        else:
            logger.info("Anthropic API key: configured ✓")

    if "openai" in providers_needed:
        key = os.environ.get("OPENAI_API_KEY", "")
        if not key:
            logger.warning(
                "⚠️  OPENAI_API_KEY not set. Agents using OpenAI will fail."
            )
        else:
            logger.info("OpenAI API key: configured ✓")

    if "gemini" in providers_needed:
        key = os.environ.get("GEMINI_API_KEY", "")
        if not key:
            logger.warning(
                "⚠️  GEMINI_API_KEY not set. Agents using Gemini will fail."
            )
        else:
            logger.info("Gemini API key: configured ✓")

    if "local" in providers_needed:
        base_url = os.environ.get("LOCAL_LLM_BASE_URL", "http://localhost:1234/v1")
        logger.info("Local LLM endpoint: %s", base_url)


# ── CLI entry point ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    reload = os.environ.get("RELOAD", "false").lower() in ("true", "1")

    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=reload,
        log_level=log_level.lower(),
    )
